import 'package:get_it/get_it.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../repositories/interfaces/attendance_repository_interface.dart';
import '../repositories/attendance_repository.dart';
import '../repositories/student_repository.dart';
import '../repositories/teacher_repository.dart';
import '../services/interfaces/attendance_service_interface.dart';
import '../services/interfaces/student_service_interface.dart';
import '../services/interfaces/teacher_service_interface.dart';
import '../services/interfaces/export_service_interface.dart';
import '../services/implementations/attendance_service.dart';
import '../services/implementations/student_service.dart';
import '../services/implementations/teacher_service.dart';
import '../services/implementations/export_service.dart';
import '../utils/file_helper.dart';
import '../utils/permissions_helper.dart';
import '../utils/qr_validator.dart';
import '../cubits/attendance_cubit.dart';

final serviceLocator = GetIt.instance;

Future<void> setupDependencies() async {
  // Core
  final supabaseClient = Supabase.instance.client;

  // Repositories
  serviceLocator.registerLazySingleton<IAttendanceRepository>(
    () => SupabaseAttendanceRepository(supabaseClient),
  );
  
  serviceLocator.registerLazySingleton<IStudentRepository>(
    () => SupabaseStudentRepository(supabaseClient),
  );
  
  serviceLocator.registerLazySingleton<ITeacherRepository>(
    () => SupabaseTeacherRepository(supabaseClient),
  );

  // Utils
  serviceLocator.registerLazySingleton(() => FileHelper());
  serviceLocator.registerLazySingleton(() => PermissionsHelper());
  serviceLocator.registerLazySingleton(() => QRValidator());

  // Services
  serviceLocator.registerLazySingleton<ITeacherService>(
    () => TeacherService(
      serviceLocator<ITeacherRepository>(),
    ),
  );

  serviceLocator.registerLazySingleton<IStudentService>(
    () => StudentService(
      serviceLocator<IStudentRepository>(),
    ),
  );

  serviceLocator.registerLazySingleton<IExportService>(
    () => ExportService(
      serviceLocator<FileHelper>(),
      serviceLocator<PermissionsHelper>(),
    ),
  );

  serviceLocator.registerLazySingleton<IAttendanceService>(
    () => AttendanceService(
      serviceLocator<IAttendanceRepository>(),
      serviceLocator<ITeacherService>(),
      serviceLocator<IStudentService>(),
      serviceLocator<QRValidator>(),
    ),
  );

  // Cubits
  serviceLocator.registerFactory(
    () => AttendanceCubit(serviceLocator<IAttendanceService>()),
  );
}
