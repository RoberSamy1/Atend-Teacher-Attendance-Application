import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/auth_service.dart';

// Auth States
abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class AuthAuthenticated extends AuthState {
  final User user;

  const AuthAuthenticated(this.user);

  @override
  List<Object> get props => [user];
}

class AuthUnauthenticated extends AuthState {}

class AuthError extends AuthState {
  final String message;

  const AuthError(this.message);

  @override
  List<Object> get props => [message];
}

// Auth Cubit
class AuthCubit extends Cubit<AuthState> {
  AuthCubit() : super(AuthInitial()) {
    _initializeAuth();
  }

  void _initializeAuth() {
    final currentUser = AuthService.currentUser;
    if (currentUser != null) {
      emit(AuthAuthenticated(currentUser));
    } else {
      emit(AuthUnauthenticated());
    }

    // Listen to auth state changes
    AuthService.authStateChanges.listen((authState) {
      if (authState.session != null) {
        emit(AuthAuthenticated(authState.session!.user));
      } else {
        emit(AuthUnauthenticated());
      }
    });
  }

  Future<void> signIn(String email, String password) async {
    try {
      emit(AuthLoading());
      await AuthService.signInWithEmail(email: email, password: password);
      // State will be updated by the auth state listener
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> signUp(String email, String password, String fullName) async {
    try {
      emit(AuthLoading());
      await AuthService.signUpWithEmail(
        email: email,
        password: password,
        data: {'full_name': fullName},
      );
      // State will be updated by the auth state listener
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> signOut() async {
    try {
      emit(AuthLoading());
      await AuthService.signOut();
      // State will be updated by the auth state listener
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  void clearError() {
    if (state is AuthError) {
      emit(AuthUnauthenticated());
    }
  }
}

