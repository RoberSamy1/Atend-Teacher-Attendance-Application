import 'package:atten/services/interfaces/attendance_service_interface.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/attendance_record.dart';
import '../models/student.dart';
import '../models/subject.dart';
import '../services/attendance_service.dart';

// Attendance States
abstract class AttendanceState extends Equatable {
  const AttendanceState();

  @override
  List<Object?> get props => [];
}

class AttendanceInitial extends AttendanceState {}

class AttendanceLoading extends AttendanceState {}

class AttendanceLoaded extends AttendanceState {
  final List<AttendanceRecord> records;
  final List<Student> students;
  final List<Subject> subjects;

  const AttendanceLoaded({
    required this.records,
    required this.students,
    required this.subjects,
  });

  @override
  List<Object> get props => [records, students, subjects];
}

class AttendanceError extends AttendanceState {
  final String message;

  const AttendanceError(this.message);

  @override
  List<Object> get props => [message];
}

class AttendanceRecordAdded extends AttendanceState {
  final AttendanceRecord record;

  const AttendanceRecordAdded(this.record);

  @override
  List<Object> get props => [record];
}

class AttendanceExported extends AttendanceState {
  final String filePath;

  const AttendanceExported(this.filePath);

  @override
  List<Object> get props => [filePath];
}

// Attendance Cubit
class AttendanceCubit extends Cubit<AttendanceState> {
  AttendanceCubit(IAttendanceService iAttendanceService) : super(AttendanceInitial());

  Future<void> loadAttendanceData() async {
    try {
      emit(AttendanceLoading());
      
      final records = await AttendanceService.getAttendanceRecords();
      final students = await AttendanceService.getAllStudents();
      final teacherInfo = await AttendanceService.getCurrentTeacherInfo();
      final now = DateTime.now();
      final subjects = teacherInfo != null ? [Subject(
        id: teacherInfo['subject_id'] ?? '',
        subjectCode: teacherInfo['subject_code'] ?? '',
        subjectName: teacherInfo['subject_name'] ?? '',
        createdAt: now,
        updatedAt: now,
      )] : <Subject>[];

      emit(AttendanceLoaded(
        records: records,
        students: students,
        subjects: subjects,
      ));
    } catch (e) {
      emit(AttendanceError(e.toString()));
    }
  }

  Future<void> markAttendance({
    required String studentId,
    required String subjectId,
    required bool isPresent,
    String? notes,
  }) async {
    try {
      emit(AttendanceLoading());
      
      final record = await AttendanceService.recordAttendance(
        studentId,
        location: notes,
      );

      emit(AttendanceRecordAdded(record));
      
      // Reload data to get updated records
      await loadAttendanceData();
    } catch (e) {
      emit(AttendanceError(e.toString()));
    }
  }

  Future<void> scanQRCode(String qrData) async {
    try {
      emit(AttendanceLoading());
      
      // QR code data should contain student ID
      final record = await AttendanceService.recordAttendance(qrData);
      
      emit(AttendanceRecordAdded(record));
      
      // Reload data to get updated records
      await loadAttendanceData();
    } catch (e) {
      emit(AttendanceError(e.toString()));
    }
  }

  Future<void> exportAttendance({
    required DateTime startDate,
    required DateTime endDate,
    String? subjectId,
  }) async {
    try {
      emit(AttendanceLoading());
      
      // TODO: Implement actual export functionality
      final filePath = 'attendance_export.csv';
      
      // For now, just notify that export is completed
      emit(AttendanceExported(filePath));
    } catch (e) {
      emit(AttendanceError(e.toString()));
    }
  }

  Future<void> getAttendanceHistory({
    DateTime? startDate,
    DateTime? endDate,
    String? subjectId,
  }) async {
    try {
      emit(AttendanceLoading());
      
      final records = await AttendanceService.getAttendanceRecords(
        startDate: startDate,
        endDate: endDate,
      );

      final students = await AttendanceService.getAllStudents();
      final teacherInfo = await AttendanceService.getCurrentTeacherInfo();
      final now = DateTime.now();
      final subjects = teacherInfo != null ? [Subject(
        id: teacherInfo['subject_id'] ?? '',
        subjectCode: teacherInfo['subject_code'] ?? '',
        subjectName: teacherInfo['subject_name'] ?? '',
        createdAt: now,
        updatedAt: now,
      )] : <Subject>[];

      emit(AttendanceLoaded(
        records: records,
        students: students,
        subjects: subjects,
      ));
    } catch (e) {
      emit(AttendanceError(e.toString()));
    }
  }

  void clearError() {
    if (state is AttendanceError) {
      emit(AttendanceInitial());
    }
  }
}

