import 'package:logger/logger.dart';

class ExportException implements Exception {
  final String message;
  final String? details;
  final dynamic originalError;

  ExportException(this.message, {this.details, this.originalError});

  @override
  String toString() {
    if (details != null) {
      return 'ExportException: $message (Details: $details)';
    }
    return 'ExportException: $message';
  }
}
