import 'package:atten/screens/scan_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/lecture.dart';
import 'attendance_history_screen.dart';
import '../services/supabase_service.dart';
import '../services/export_service.dart';

class TeacherAttendanceScreen extends StatefulWidget {
  final String teacherId;
  final String subjectId;
  final String subjectName;
  final String? classId;
  final String? className;
  final Lecture? lecture;

  const TeacherAttendanceScreen({
    super.key,
    required this.teacherId,
    required this.subjectId,
    required this.subjectName,
    this.classId,
    this.className,
    this.lecture,
  });

  @override
  State<TeacherAttendanceScreen> createState() =>
      _TeacherAttendanceScreenState();
}

class _TeacherAttendanceScreenState extends State<TeacherAttendanceScreen> {
  final TextEditingController _studentIdController = TextEditingController();
  List<Map<String, dynamic>> _attendanceRecords = [];
  bool _isLoading = false;
  bool _isExporting = false;
  String _errorMessage = '';
  String _successMessage = '';

  @override
  void initState() {
    super.initState();
    _loadTodayAttendance();
  }

  @override
  void dispose() {
    _studentIdController.dispose();
    super.dispose();
  }

  Future<void> _loadTodayAttendance() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      final records = await SupabaseService.getAttendanceRecords(
        startDate: startOfDay,
        endDate: endOfDay,
      );

      final filteredRecords = records.where((record) {
        return record["subject_id"] == widget.subjectId &&
            (widget.lecture?.id == null || record["lecture_id"] == widget.lecture?.id);
      }).toList();

      setState(() {
        _attendanceRecords = filteredRecords;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading attendance records: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _markAttendance(String status) async {
    final studentId = _studentIdController.text.trim();
    if (studentId.isEmpty) {
      _showMessage("Please enter a student ID", isError: true);
      return;
    }

    if (widget.classId == null || widget.classId!.isEmpty) {
      _showMessage("Class ID is missing. Cannot record attendance.", isError: true);
      return;
    }

    if (widget.subjectId.isEmpty) {
      _showMessage("Subject ID is missing. Cannot record attendance.", isError: true);
      return;
    }

    setState(() => _isLoading = true);

    try {
      final students = await SupabaseService.select(
        table: 'students',
        columns: '*',
        filter: studentId,
      );

      if (students.isEmpty) {
        _showMessage('Student with ID $studentId not found', isError: true);
        return;
      }

      final student = students.first;
      await SupabaseService.recordAttendance(
        studentId: studentId,
        studentName: student['name'],
        classId: widget.classId ?? '',
        subjectId: widget.subjectId,
        lectureId: widget.lecture?.id,
        status: status,
      );

      _showMessage('Attendance marked as $status for ${student['name']}');
      _studentIdController.clear();
      _loadTodayAttendance();

      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AttendanceHistoryScreen(studentId: studentId),
          ),
        );
      }
    } catch (e) {
      _showMessage('Error marking attendance: $e', isError: true);
    }

    setState(() => _isLoading = false);
  }

  void _showMessage(String message, {bool isError = false}) {
    HapticFeedback.lightImpact();
    setState(() {
      if (isError) {
        _errorMessage = message;
        _successMessage = '';
      } else {
        _successMessage = message;
        _errorMessage = '';
      }
    });

    if (!isError) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) setState(() => _successMessage = '');
      });
    }
  }

  Future<void> _exportData(bool isSummary) async {
    setState(() => _isExporting = true);

    try {
      final filePath = isSummary
          ? await ExportService.exportAttendanceSummaryToExcel(
              subjectId: widget.subjectId,
              subjectName: widget.subjectName,
              classId: widget.classId,
              className: widget.className,
            )
          : await ExportService.exportAttendanceToExcel(
              subjectId: widget.subjectId,
              subjectName: widget.subjectName,
              classId: widget.classId,
              className: widget.className,
            );

      _showMessage('Data exported successfully to: $filePath');

      if (mounted) {
        _showExportDialog(filePath, isSummary);
      }
    } catch (e) {
      _showMessage('Error exporting data: $e', isError: true);
    }

    setState(() => _isExporting = false);
  }

  void _showExportDialog(String filePath, bool isSummary) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green[600]),
            const SizedBox(width: 12),
            const Text('Export Successful'),
          ],
        ),
        content:
            Text('${isSummary ? 'Summary' : 'Data'} exported to:\n$filePath'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showExportOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Export Options',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 20),
            _buildExportOption(
              icon: Icons.table_chart,
              title: 'Attendance Records',
              subtitle: 'Export all attendance records for this subject',
              onTap: () {
                Navigator.pop(context);
                _exportData(false);
              },
            ),
            _buildExportOption(
              icon: Icons.summarize,
              title: 'Attendance Summary',
              subtitle: 'Export student statistics and summary',
              onTap: () {
                Navigator.pop(context);
                _exportData(true);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExportOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey[300]!),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey[400]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.primary.withOpacity(0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mark Attendance',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _studentIdController,
            decoration: InputDecoration(
              hintText: 'Enter Student ID',
              prefixIcon: const Icon(Icons.person),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildAttendanceButton(
                  'Present',
                  Icons.check_circle,
                  Colors.green,
                  () => _markAttendance('present'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildAttendanceButton(
                  'Absent',
                  Icons.cancel,
                  Colors.red,
                  () => _markAttendance('absent'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceButton(
      String text, IconData icon, Color color, VoidCallback onPressed) {
    return ElevatedButton.icon(
      onPressed: _isLoading ? null : onPressed,
      icon: Icon(icon, color: Colors.white),
      label: Text(text, style: const TextStyle(color: Colors.white)),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  Widget _buildMessageCard(String message, bool isError) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isError ? Colors.red[50] : Colors.green[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isError ? Colors.red[200]! : Colors.green[200]!,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: isError ? Colors.red[700] : Colors.green[700],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: isError ? Colors.red[800] : Colors.green[800],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceList() {
    if (_attendanceRecords.isEmpty) {
      return Expanded(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.list_alt, size: 80, color: Colors.grey[300]),
              const SizedBox(height: 16),
              Text(
                'No attendance records for today',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Start marking attendance to see records here',
                style: TextStyle(color: Colors.grey[500]),
              ),
            ],
          ),
        ),
      );
    }

    return Expanded(
      child: ListView.separated(
        itemCount: _attendanceRecords.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final record = _attendanceRecords[index];
          final isPresent = record['status'] == 'present';

          return Card(
            elevation: 2,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AttendanceHistoryScreen(
                      studentId: record['student_id'],
                    ),
                  ),
                );
              },
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isPresent ? Colors.green : Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isPresent ? Icons.check : Icons.close,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            record['student_name'] ?? 'Unknown',
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'ID: ${record['student_id']}',
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                          Text(
                            'Time: ${DateTime.parse(record['timestamp']).toLocal().toString().substring(11, 16)}',
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: isPresent ? Colors.green[100] : Colors.red[100],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        record['status'].toUpperCase(),
                        style: TextStyle(
                          color:
                              isPresent ? Colors.green[700] : Colors.red[700],
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.subjectName),
            if (widget.lecture != null)
              Text(
                widget.lecture!.name,
                style: const TextStyle(fontSize: 14, color: Colors.white70),
              ),
            if (widget.className != null)
              Text(
                widget.className!,
                style: const TextStyle(fontSize: 12, color: Colors.white54),
              ),
          ],
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: _isExporting
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : const Icon(Icons.download),
            onPressed: _isExporting ? null : _showExportOptions,
            tooltip: 'Export Data',
          ),
          IconButton(
            icon: const Icon(Icons.qr_code_scanner),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ScanScreen()),
            ),
            tooltip: 'Scan QR Code',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildQuickActions(),
            const SizedBox(height: 20),
            if (_successMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: _buildMessageCard(_successMessage, false),
              ),
            if (_errorMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: _buildMessageCard(_errorMessage, true),
              ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Today\'s Attendance',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '${_attendanceRecords.length} records',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (_isLoading && _attendanceRecords.isEmpty)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else
              _buildAttendanceList(),
          ],
        ),
      ),
    );
  }
}
