import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import '../models/student.dart';

class StudentSearchScreen extends StatefulWidget {
  const StudentSearchScreen({super.key});

  @override
  State<StudentSearchScreen> createState() => _StudentSearchScreenState();
}

class _StudentSearchScreenState extends State<StudentSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _searchResults = [];
  bool _isLoading = false;
  String _errorMessage = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _searchStudents(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        _searchResults = [];
        _errorMessage = '';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      // Search students by name or student ID
      final students = await SupabaseService.select(
        table: 'students',
        columns: '*',
      );

      // Filter results locally (in a real app, you'd do this server-side)
      final filteredStudents = students.where((student) {
        final name = student['name'].toString().toLowerCase();
        final studentId = student['student_id'].toString().toLowerCase();
        final searchQuery = query.toLowerCase();
        return name.contains(searchQuery) || studentId.contains(searchQuery);
      }).toList();

      setState(() {
        _searchResults = filteredStudents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error searching students: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _showStudentDetails(Map<String, dynamic> student) async {
    try {
      // Get student attendance summary
      final attendanceSummary = await SupabaseService.getAttendanceRecords(
        studentId: student['student_id'],
      );

      if (!mounted) return;

      showDialog(
        context: context,
        builder: (context) => StudentDetailsDialog(
          student: student,
          attendanceSummary: attendanceSummary,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading student details: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Search field
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by student name or ID...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey[100],
              ),
              onChanged: _searchStudents,
            ),
            const SizedBox(height: 16),

            // Error message
            if (_errorMessage.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _errorMessage,
                  style: TextStyle(color: Colors.red[800]),
                ),
              ),

            // Loading indicator
            if (_isLoading)
              const Expanded(
                child: Center(child: CircularProgressIndicator()),
              ),

            // Search results
            if (!_isLoading && _searchResults.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    final student = _searchResults[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: const Color(0xFF2E3A59),
                          child: Text(
                            student['name'][0].toUpperCase(),
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                        title: Text(student['name']),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('ID: ${student['student_id']}'),
                            if (student['department'] != null)
                              Text('Department: ${student['department']}'),
                            if (student['year'] != null)
                              Text('Year: ${student['year']}'),
                          ],
                        ),
                        trailing: const Icon(Icons.arrow_forward_ios),
                        onTap: () => _showStudentDetails(student),
                      ),
                    );
                  },
                ),
              ),

            // Empty state
            if (!_isLoading &&
                _searchResults.isEmpty &&
                _searchController.text.isNotEmpty)
              const Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search_off, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text(
                        'No students found',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),

            // Initial state
            if (_searchController.text.isEmpty)
              const Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.person_search, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text(
                        'Search for students by name or ID',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class StudentDetailsDialog extends StatelessWidget {
  final Map<String, dynamic> student;
  final List<Map<String, dynamic>> attendanceSummary;

  const StudentDetailsDialog({
    super.key,
    required this.student,
    required this.attendanceSummary,
  });

  @override
  Widget build(BuildContext context) {
    // Calculate total attendance and absence counts
    int totalPresent = 0;
    int totalAbsent = 0;

    for (final record in attendanceSummary) {
      totalPresent += (record['present_count'] as int? ?? 0);
      totalAbsent += (record['absent_count'] as int? ?? 0);
    }

    return AlertDialog(
      title: Text(student['name']),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Student info
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Student ID: ${student['student_id']}'),
                    if (student['email'] != null)
                      Text('Email: ${student['email']}'),
                    if (student['department'] != null)
                      Text('Department: ${student['department']}'),
                    if (student['year'] != null)
                      Text('Year: ${student['year']}'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Overall attendance summary
            Card(
              color: Colors.blue[50],
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Overall Attendance Summary',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            Text(
                              '$totalPresent',
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                              ),
                            ),
                            const Text('Present'),
                          ],
                        ),
                        Column(
                          children: [
                            Text(
                              '$totalAbsent',
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                              ),
                            ),
                            const Text('Absent'),
                          ],
                        ),
                        Column(
                          children: [
                            Text(
                              '${totalPresent + totalAbsent}',
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue,
                              ),
                            ),
                            const Text('Total'),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Subject-wise attendance
            if (attendanceSummary.isNotEmpty) ...[
              const Text(
                'Subject-wise Attendance',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 200,
                child: ListView.builder(
                  itemCount: attendanceSummary.length,
                  itemBuilder: (context, index) {
                    final record = attendanceSummary[index];
                    final present = record['present_count'] as int? ?? 0;
                    final absent = record['absent_count'] as int? ?? 0;
                    final total = present + absent;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        title:
                            Text(record['subject_name'] ?? 'Unknown Subject'),
                        subtitle: record['class_name'] != null
                            ? Text('Class: ${record['class_name']}')
                            : null,
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              '$present/$total',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              total > 0
                                  ? '${(present / total * 100).toStringAsFixed(1)}%'
                                  : '0%',
                              style: TextStyle(
                                color: present / (total > 0 ? total : 1) >= 0.75
                                    ? Colors.green
                                    : Colors.red,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ] else
              const Text('No attendance records found for this student.'),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}
