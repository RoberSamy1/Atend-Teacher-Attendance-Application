import 'package:flutter/material.dart';
import '../models/lecture.dart';
import '../services/lecture_service.dart';
import '../services/auth_service.dart';
import 'teacher_attendance_screen.dart';

class SavedLecturesScreen extends StatefulWidget {
  const SavedLecturesScreen({super.key});

  @override
  State<SavedLecturesScreen> createState() => _SavedLecturesScreenState();
}

class _SavedLecturesScreenState extends State<SavedLecturesScreen> {
  List<Map<String, dynamic>> _lectures = [];
  bool _isLoading = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadLectures();
  }

  Future<void> _loadLectures() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      // Get all lectures with subject details
      final teacherProfile = await AuthService.getTeacherProfile(AuthService.currentUser!.id);
      if (teacherProfile == null) throw Exception('Teacher profile not found');
      
      final lectures = await LectureService.getLecturesWithDetails(teacherProfile['id']);
      setState(() {
        _lectures = lectures;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading lectures: $e';
        _isLoading = false;
      });
    }
  }

  void _navigateToAttendance(Map<String, dynamic> lectureData) {
    final lecture = Lecture(
      id: lectureData['id'],
      name: lectureData['name'],
      subjectId: lectureData['subject_id'],
      teacherId: lectureData['teacher_id'],
      date: DateTime.parse(lectureData['date']),
      createdAt: DateTime.parse(lectureData['created_at']),
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TeacherAttendanceScreen(
          teacherId: lectureData['teacher_id'],
          subjectId: lectureData['subject_id'],
          subjectName: lectureData['subject_name'] ?? 'Unknown Subject',
          classId: lectureData['class_id'],
          className: lectureData['class_name'],
          lecture: lecture,
        ),
      ),
    );
  }

  Widget _buildLectureCard(Map<String, dynamic> lecture) {
    final date = DateTime.parse(lecture['date']);
    final formattedDate = '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => _navigateToAttendance(lecture),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.school,
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          lecture['name'],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          lecture['subject_name'] ?? 'Unknown Subject',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(Icons.calendar_today, size: 16, color: Colors.grey[600]),
                      const SizedBox(width: 8),
                      Text(
                        formattedDate,
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  if (lecture['attendance_count'] != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${lecture['attendance_count']} students',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage.isNotEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.red[300]),
            const SizedBox(height: 16),
            Text(
              _errorMessage,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.red[700]),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadLectures,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_lectures.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.folder_open, size: 64, color: Colors.grey[300]),
            const SizedBox(height: 16),
            Text(
              'No lectures yet',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.grey[600],
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Create a new lecture to get started',
              style: TextStyle(color: Colors.grey[500]),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadLectures,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _lectures.length,
        itemBuilder: (context, index) => _buildLectureCard(_lectures[index]),
      ),
    );
  }
}
