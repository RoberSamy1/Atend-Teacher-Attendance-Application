class QRValidator {
  // Validate student ID format
  static bool isValidStudentId(String studentId) {
    if (studentId.isEmpty) return false;
    
    // Remove whitespace
    studentId = studentId.trim();
    
    // Check minimum length
    if (studentId.length < 3) return false;
    
    // Check maximum length
    if (studentId.length > 20) return false;
    
    // Check for valid characters (alphanumeric, hyphens, underscores)
    final validPattern = RegExp(r'^[a-zA-Z0-9_-]+$');
    return validPattern.hasMatch(studentId);
  }

  // Extract student ID from QR code data
  static String? extractStudentId(String qrData) {
    if (qrData.isEmpty) return null;
    
    // Try different formats that might be in QR codes
    
    // Format 1: Plain student ID
    if (isValidStudentId(qrData)) {
      return qrData.trim().toUpperCase();
    }
    
    // Format 2: JSON format {"student_id": "STU001"}
    try {
      final jsonPattern = RegExp(r'"student_id"\s*:\s*"([^"]+)"');
      final match = jsonPattern.firstMatch(qrData);
      if (match != null) {
        final studentId = match.group(1)!;
        if (isValidStudentId(studentId)) {
          return studentId.trim().toUpperCase();
        }
      }
    } catch (e) {
      // Continue to next format
    }
    
    // Format 3: URL format with student ID parameter
    try {
      final uri = Uri.tryParse(qrData);
      if (uri != null) {
        final studentId = uri.queryParameters['student_id'] ?? 
                         uri.queryParameters['id'] ?? 
                         uri.queryParameters['studentId'];
        if (studentId != null && isValidStudentId(studentId)) {
          return studentId.trim().toUpperCase();
        }
      }
    } catch (e) {
      // Continue to next format
    }
    
    // Format 4: Key-value format "STUDENT_ID:STU001"
    try {
      final kvPattern = RegExp(r'(?:STUDENT_ID|ID|STUDENT)[:=]\s*([a-zA-Z0-9_-]+)', caseSensitive: false);
      final match = kvPattern.firstMatch(qrData);
      if (match != null) {
        final studentId = match.group(1)!;
        if (isValidStudentId(studentId)) {
          return studentId.trim().toUpperCase();
        }
      }
    } catch (e) {
      // Continue to next format
    }
    
    // Format 5: Extract any alphanumeric sequence that looks like a student ID
    try {
      final patterns = [
        RegExp(r'[A-Z]{2,}\d+', caseSensitive: false),
        RegExp(r'[A-Z]{2,3}\d{3,6}', caseSensitive: false),
        RegExp(r'\d{6,10}'),
      ];
      
      for (final pattern in patterns) {
        final match = pattern.firstMatch(qrData);
        if (match != null) {
          final studentId = match.group(0)!;
          if (isValidStudentId(studentId)) {
            return studentId.trim().toUpperCase();
          }
        }
      }
    } catch (e) {
      // No valid student ID found
    }
    
    return null;
  }

  // Validate QR code data and return validation result
  static QRValidationResult validateQRData(String qrData) {
    if (qrData.isEmpty) {
      return QRValidationResult(
        isValid: false,
        studentId: null,
        error: 'QR code data is empty',
      );
    }
    
    final studentId = extractStudentId(qrData);
    
    if (studentId == null) {
      return QRValidationResult(
        isValid: false,
        studentId: null,
        error: 'No valid student ID found in QR code',
      );
    }
    
    return QRValidationResult(
      isValid: true,
      studentId: studentId,
      error: null,
    );
  }

  // Generate sample QR data for testing
  static List<String> generateSampleQRData() {
    return [
      'STU001',
      '{"student_id": "STU002"}',
      'https://university.edu/student?student_id=STU003',
      'STUDENT_ID:STU004',
      'ID=STU005',
      '2024001234',
      'CS001',
      'ENG002',
    ];
  }
}

class QRValidationResult {
  final bool isValid;
  final String? studentId;
  final String? error;

  QRValidationResult({
    required this.isValid,
    this.studentId,
    this.error,
  });

  @override
  String toString() {
    return 'QRValidationResult{isValid: $isValid, studentId: $studentId, error: $error}';
  }
}

