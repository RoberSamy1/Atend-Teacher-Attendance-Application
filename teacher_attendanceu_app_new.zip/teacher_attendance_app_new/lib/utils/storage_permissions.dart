import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/material.dart';

class StoragePermissions {
  static Future<bool> requestStoragePermissions() async {
    try {
      // Check current permissions
      Map<Permission, PermissionStatus> permissions = await [
        Permission.storage,
        Permission.manageExternalStorage,
        Permission.photos,
        Permission.videos,
        Permission.audio,
      ].request();

      // Check if all permissions are granted
      bool allGranted = permissions.values.every(
        (status) => status == PermissionStatus.granted,
      );

      if (!allGranted) {
        // Try requesting individual permissions for Android 13+
        if (await Permission.photos.isDenied) {
          await Permission.photos.request();
        }
        
        if (await Permission.videos.isDenied) {
          await Permission.videos.request();
        }
        
        if (await Permission.audio.isDenied) {
          await Permission.audio.request();
        }

        // For older Android versions
        if (await Permission.storage.isDenied) {
          await Permission.storage.request();
        }

        // Check again after requesting
        permissions = await [
          Permission.storage,
          Permission.manageExternalStorage,
          Permission.photos,
          Permission.videos,
          Permission.audio,
        ].request();

        allGranted = permissions.values.any(
          (status) => status == PermissionStatus.granted,
        );
      }

      return allGranted;
    } catch (e) {
      debugPrint('Error requesting storage permissions: $e');
      return false;
    }
  }

  static Future<bool> hasStoragePermissions() async {
    try {
      // Check if we have any of the required permissions
      bool hasStorage = await Permission.storage.isGranted;
      bool hasManageStorage = await Permission.manageExternalStorage.isGranted;
      bool hasPhotos = await Permission.photos.isGranted;
      bool hasVideos = await Permission.videos.isGranted;
      bool hasAudio = await Permission.audio.isGranted;

      return hasStorage || hasManageStorage || hasPhotos || hasVideos || hasAudio;
    } catch (e) {
      debugPrint('Error checking storage permissions: $e');
      return false;
    }
  }

  static Future<void> showPermissionDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Storage Permission Required'),
          content: const Text(
            'This app needs storage permission to save attendance reports and export data. '
            'Please grant the permission to continue.',
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Grant Permission'),
              onPressed: () async {
                Navigator.of(context).pop();
                await requestStoragePermissions();
              },
            ),
            TextButton(
              child: const Text('Open Settings'),
              onPressed: () {
                Navigator.of(context).pop();
                openAppSettings();
              },
            ),
          ],
        );
      },
    );
  }

  static Future<bool> checkAndRequestPermissions(BuildContext context) async {
    bool hasPermissions = await hasStoragePermissions();
    
    if (!hasPermissions) {
      await showPermissionDialog(context);
      hasPermissions = await requestStoragePermissions();
    }
    
    return hasPermissions;
  }

  static Future<PermissionStatus> getCameraPermissionStatus() async {
    return await Permission.camera.status;
  }

  static Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status == PermissionStatus.granted;
  }

  static Future<void> showCameraPermissionDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Camera Permission Required'),
          content: const Text(
            'This app needs camera permission to scan QR codes for attendance. '
            'Please grant the permission to continue.',
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Grant Permission'),
              onPressed: () async {
                Navigator.of(context).pop();
                await requestCameraPermission();
              },
            ),
            TextButton(
              child: const Text('Open Settings'),
              onPressed: () {
                Navigator.of(context).pop();
                openAppSettings();
              },
            ),
          ],
        );
      },
    );
  }
}

