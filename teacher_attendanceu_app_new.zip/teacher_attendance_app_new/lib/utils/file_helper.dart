import 'dart:io';
import 'package:path_provider/path_provider.dart';

class FileHelper {
  // Get the documents directory
  Future<Directory> getDocumentsDirectory() async {
    return await getApplicationDocumentsDirectory();
  }

  // Get the downloads directory (Android) with app-specific folder
  Future<Directory?> getDownloadsDirectory() async {
    if (Platform.isAndroid) {
      try {
        // Create app-specific folder in Downloads
        final downloadDir = Directory('/storage/emulated/0/Download/Teacher_Attendance');
        if (!await downloadDir.exists()) {
          await downloadDir.create(recursive: true);
        }
        return downloadDir;
      } catch (e) {
        // Fallback to external storage with app folder
        final externalDir = await getExternalStorageDirectory();
        if (externalDir != null) {
          final appDir = Directory('${externalDir.path}/Teacher_Attendance');
          if (!await appDir.exists()) {
            await appDir.create(recursive: true);
          }
          return appDir;
        }
        return await getApplicationDocumentsDirectory();
      }
    } else {
      // For iOS and other platforms - create app folder in documents
      final documentsDir = await getApplicationDocumentsDirectory();
      final appDir = Directory('${documentsDir.path}/Teacher_Attendance');
      if (!await appDir.exists()) {
        await appDir.create(recursive: true);
      }
      return appDir;
    }
  }

  // Get the temporary directory
  Future<Directory> getTempDirectory() async {
    return await getTemporaryDirectory();
  }

  // Check if file exists
  Future<bool> fileExists(String filePath) async {
    final file = File(filePath);
    return await file.exists();
  }

  // Delete file
  Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Get file size
  Future<int> getFileSize(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        return await file.length();
      }
      return 0;
    } catch (e) {
      return 0;
    }
  }

  // Format file size
  String formatFileSize(int bytes) {
    if (bytes < 1024) {
      return '$bytes B';
    } else if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    } else if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    } else {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
  }

  // Get file extension
  String getFileExtension(String filePath) {
    return filePath.split('.').last.toLowerCase();
  }

  // Get file name without extension
  String getFileNameWithoutExtension(String filePath) {
    final fileName = filePath.split('/').last;
    final lastDotIndex = fileName.lastIndexOf('.');
    if (lastDotIndex != -1) {
      return fileName.substring(0, lastDotIndex);
    }
    return fileName;
  }

  // Get file name with extension
  String getFileName(String filePath) {
    return filePath.split('/').last;
  }

  // Create directory if it doesn't exist
  Future<Directory> createDirectory(String path) async {
    final directory = Directory(path);
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  // List files in directory
  Future<List<FileSystemEntity>> listFiles(String directoryPath) async {
    try {
      final directory = Directory(directoryPath);
      if (await directory.exists()) {
        return await directory.list().toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // Copy file
  Future<bool> copyFile(String sourcePath, String destinationPath) async {
    try {
      final sourceFile = File(sourcePath);
      if (await sourceFile.exists()) {
        await sourceFile.copy(destinationPath);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Move file
  Future<bool> moveFile(String sourcePath, String destinationPath) async {
    try {
      final sourceFile = File(sourcePath);
      if (await sourceFile.exists()) {
        await sourceFile.rename(destinationPath);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Get file modification date
  Future<DateTime?> getFileModificationDate(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        final stat = await file.stat();
        return stat.modified;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // Clean up old files (older than specified days)
  Future<int> cleanupOldFiles(String directoryPath, int daysOld) async {
    try {
      final directory = Directory(directoryPath);
      if (!await directory.exists()) {
        return 0;
      }

      final cutoffDate = DateTime.now().subtract(Duration(days: daysOld));
      final files = await directory.list().toList();
      int deletedCount = 0;

      for (final entity in files) {
        if (entity is File) {
          final stat = await entity.stat();
          if (stat.modified.isBefore(cutoffDate)) {
            try {
              await entity.delete();
              deletedCount++;
            } catch (e) {
              // Continue with other files if one fails
            }
          }
        }
      }

      return deletedCount;
    } catch (e) {
      return 0;
    }
  }

  // Get available storage space
  Future<int> getAvailableSpace(String path) async {
    try {
      final directory = Directory(path);
      final stat = await directory.stat();
      // This is a simplified implementation
      // In a real app, you might want to use platform-specific code
      return 1024 * 1024 * 1024; // Return 1GB as placeholder
    } catch (e) {
      return 0;
    }
  }

  // Validate file path
  bool isValidFilePath(String path) {
    try {
      // Check for invalid characters
      final invalidChars = ['<', '>', ':', '"', '|', '?', '*'];
      for (final char in invalidChars) {
        if (path.contains(char)) {
          return false;
        }
      }

      // Check path length
      if (path.length > 260) {
        return false;
      }

      return true;
    } catch (e) {
      return false;
    }
  }

  // Generate unique file name
  String generateUniqueFileName(String baseName, String extension) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return '${baseName}_$timestamp.$extension';
  }

  // Get MIME type from file extension
  String getMimeType(String filePath) {
    final extension = getFileExtension(filePath);
    switch (extension) {
      case 'xlsx':
        return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      case 'xls':
        return 'application/vnd.ms-excel';
      case 'csv':
        return 'text/csv';
      case 'pdf':
        return 'application/pdf';
      case 'txt':
        return 'text/plain';
      case 'json':
        return 'application/json';
      default:
        return 'application/octet-stream';
    }
  }
}

