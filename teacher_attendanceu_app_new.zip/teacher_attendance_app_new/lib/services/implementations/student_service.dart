import '../interfaces/student_service_interface.dart';
import '../../repositories/student_repository.dart';
import '../../models/student.dart';

class StudentService implements IStudentService {
  final IStudentRepository _studentRepository;

  StudentService(this._studentRepository);

  @override
  Future<List<Student>> getAllStudents() async {
    try {
      return await _studentRepository.getAllStudents();
    } catch (e) {
      throw Exception('Failed to get all students: $e');
    }
  }

  @override
  Future<List<Student>> searchStudents(String query) async {
    try {
      if (query.trim().isEmpty) {
        return [];
      }
      return await _studentRepository.searchStudents(query);
    } catch (e) {
      throw Exception('Failed to search students: $e');
    }
  }

  @override
  Future<Student> addOrUpdateStudent(Student student) async {
    try {
      _validateStudentData(student);
      return await _studentRepository.addOrUpdateStudent(student);
    } catch (e) {
      throw Exception('Failed to add or update student: $e');
    }
  }

  // Private helper methods
  void _validateStudentData(Student student) {
    if (student.studentId.trim().isEmpty) {
      throw Exception('Student ID cannot be empty');
    }
    if (student.name.trim().isEmpty) {
      throw Exception('Student name cannot be empty');
    }
    // Add more validation as needed
  }
}
