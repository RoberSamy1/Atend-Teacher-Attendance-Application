import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:logger/logger.dart';
import '../interfaces/export_service_interface.dart';
import '../../utils/file_helper.dart';
import '../../utils/permissions_helper.dart';
import '../../exceptions/export_exception.dart';

class ExportService implements IExportService {
  final FileHelper _fileHelper;
  final PermissionsHelper _permissionsHelper;
  final Logger _logger;

  ExportService(this._fileHelper, this._permissionsHelper) : _logger = Logger();

  @override
  Future<String> exportToExcel(List<Map<String, dynamic>> data, String fileName) async {
    try {
      _logger.i('Starting Excel export for file: $fileName');

      if (data.isEmpty) {
        throw ExportException('No data to export');
      }

      if (!_fileHelper.isValidFilePath(fileName)) {
        throw ExportException('Invalid file name: $fileName');
      }

      // Create Excel workbook
      _logger.d('Creating Excel workbook');
      var excel = Excel.createExcel();
      Sheet sheetObject = excel['Sheet1'];

      // Add headers
      _logger.d('Adding headers to Excel file');
      var headers = data.first.keys.toList();
      for (var i = 0; i < headers.length; i++) {
        sheetObject.cell(CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0))
          ..value = headers[i]
          ..cellStyle = CellStyle(
            bold: true,
            horizontalAlign: HorizontalAlign.Center,
          );
      }

      // Add data
      _logger.d('Adding ${data.length} rows of data to Excel file');
      for (var i = 0; i < data.length; i++) {
        var row = data[i];
        var j = 0;
        row.forEach((key, value) {
          sheetObject.cell(CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1))
            ..value = value.toString()
            ..cellStyle = CellStyle(
              horizontalAlign: HorizontalAlign.Left,
            );
          j++;
        });
      }

      // Generate file bytes
      _logger.d('Generating Excel file bytes');
      var fileBytes = excel.save();
      if (fileBytes == null) {
        throw ExportException('Failed to generate Excel file');
      }

      // Get directory and save file
      _logger.d('Getting export directory');
      final directory = await _fileHelper.getDownloadsDirectory() ?? 
                       await _fileHelper.getDocumentsDirectory();
      
      final filePath = '${directory.path}/${_fileHelper.generateUniqueFileName(fileName, 'xlsx')}';
      _logger.d('Saving Excel file to: $filePath');
      
      final file = File(filePath);
      await file.writeAsBytes(fileBytes);

      _logger.i('Successfully exported Excel file to: $filePath');
      return filePath;
    } catch (e, stackTrace) {
      _logger.e('Failed to export to Excel', error: e, stackTrace: stackTrace);
      if (e is ExportException) {
        rethrow;
      }
      throw ExportException(
        'Failed to export to Excel',
        details: e.toString(),
        originalError: e,
      );
    }
  }

  @override
  Future<String> exportToCsv(List<Map<String, dynamic>> data, String fileName) async {
    try {
      _logger.i('Starting CSV export for file: $fileName');

      if (data.isEmpty) {
        throw ExportException('No data to export');
      }

      if (!_fileHelper.isValidFilePath(fileName)) {
        throw ExportException('Invalid file name: $fileName');
      }

      _logger.d('Creating CSV content');
      var csv = StringBuffer();

      // Add headers
      _logger.d('Adding headers to CSV file');
      csv.writeln(data.first.keys.join(','));

      // Add rows
      _logger.d('Adding ${data.length} rows of data to CSV file');
      for (var row in data) {
        csv.writeln(row.values.map((value) => _escapeCsvValue(value.toString())).join(','));
      }

      // Get directory and save file
      _logger.d('Getting export directory');
      final directory = await _fileHelper.getDownloadsDirectory() ?? 
                       await _fileHelper.getDocumentsDirectory();
      
      final filePath = '${directory.path}/${_fileHelper.generateUniqueFileName(fileName, 'csv')}';
      _logger.d('Saving CSV file to: $filePath');
      
      await File(filePath).writeAsString(csv.toString());

      _logger.i('Successfully exported CSV file to: $filePath');
      return filePath;
    } catch (e, stackTrace) {
      _logger.e('Failed to export to CSV', error: e, stackTrace: stackTrace);
      if (e is ExportException) {
        rethrow;
      }
      throw ExportException(
        'Failed to export to CSV',
        details: e.toString(),
        originalError: e,
      );
    }
  }

  @override
  Future<bool> saveFile(String content, String fileName, String fileType) async {
    try {
      _logger.i('Starting file save operation for: $fileName.$fileType');

      // Check storage permission
      _logger.d('Checking storage permissions');
      if (!await _permissionsHelper.isStoragePermissionGranted()) {
        _logger.d('Requesting storage permission');
        final granted = await _permissionsHelper.requestStoragePermission();
        if (!granted) {
          throw ExportException('Storage permission not granted');
        }
      }

      // Validate file name and type
      if (!_fileHelper.isValidFilePath(fileName)) {
        throw ExportException('Invalid file name: $fileName');
      }

      // Get directory and create full path
      _logger.d('Getting export directory');
      final directory = await _fileHelper.getDownloadsDirectory() ?? 
                       await _fileHelper.getDocumentsDirectory();
      
      final filePath = '${directory.path}/${_fileHelper.generateUniqueFileName(fileName, fileType)}';
      _logger.d('Saving file to: $filePath');

      // Write file
      await File(filePath).writeAsString(content);
      
      _logger.i('Successfully saved file to: $filePath');
      return true;
    } catch (e, stackTrace) {
      _logger.e('Failed to save file', error: e, stackTrace: stackTrace);
      if (e is ExportException) {
        rethrow;
      }
      throw ExportException(
        'Failed to save file',
        details: e.toString(),
        originalError: e,
      );
    }
  }

  // Private helper method
  String _escapeCsvValue(String value) {
    if (value.contains(',') || value.contains('"') || value.contains('\n')) {
      return '"${value.replaceAll('"', '""')}"';
    }
    return value;
  }
}
