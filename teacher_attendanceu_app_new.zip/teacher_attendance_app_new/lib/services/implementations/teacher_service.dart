import '../interfaces/teacher_service_interface.dart';
import '../../repositories/teacher_repository.dart';

class TeacherService implements ITeacherService {
  final ITeacherRepository _teacherRepository;

  TeacherService(this._teacherRepository);

  @override
  Future<Map<String, dynamic>?> getCurrentTeacherInfo() async {
    try {
      return await _teacherRepository.getCurrentTeacherInfo();
    } catch (e) {
      throw Exception('Failed to get current teacher info: $e');
    }
  }

  @override
  Future<String> getTeacherId() async {
    try {
      final info = await getCurrentTeacherInfo();
      if (info == null || info['teacher_id'] == null) {
        throw Exception('Teacher ID not found');
      }
      return info['teacher_id'].toString();
    } catch (e) {
      throw Exception('Failed to get teacher ID: $e');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getTeacherSubjects() async {
    try {
      final teacherId = await getTeacherId();
      return await _teacherRepository.getTeacherSubjects(teacherId);
    } catch (e) {
      throw Exception('Failed to get teacher subjects: $e');
    }
  }

  @override
  Future<bool> isTeacherActive() async {
    try {
      final info = await getCurrentTeacherInfo();
      return info != null && info['status'] == 'active';
    } catch (e) {
      return false;
    }
  }
}
