import '../../repositories/interfaces/attendance_repository_interface.dart';
import '../interfaces/attendance_service_interface.dart';
import '../interfaces/student_service_interface.dart';
import '../interfaces/teacher_service_interface.dart';
import '../../models/attendance_record.dart';
import '../../models/student.dart';
import '../../utils/date_time_helper.dart';
import '../../utils/qr_validator.dart';

class AttendanceService implements IAttendanceService {
  final IAttendanceRepository _attendanceRepository;
  final ITeacherService _teacherService;
  final IStudentService _studentService;

  AttendanceService(
    this._attendanceRepository,
    this._teacherService,
    this._studentService, QRValidator qrValidator,
  );

  @override
  Future<AttendanceRecord> recordAttendance(
    String studentId, {
    String? studentName,
    String? location,
  }) async {
    try {
      // Validate QR data if it's a QR scan
      final validationResult = QRValidator.validateQRData(studentId);
      if (!validationResult.isValid) {
        throw Exception(validationResult.error ?? 'Invalid QR code format');
      }
      studentId = validationResult.studentId ?? studentId;

      // Verify teacher is active
      final isTeacherActive = await _teacherService.isTeacherActive();
      if (!isTeacherActive) {
        throw Exception('Teacher is not active or no active subject found');
      }

      return await _attendanceRepository.recordAttendance(
        studentId,
        studentName: studentName,
        location: location,
      );
    } catch (e) {
      throw Exception('Failed to record attendance: $e');
    }
  }

  @override
  Future<List<AttendanceRecord>> getAttendanceRecords({
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      _validateDateRange(startDate, endDate);
      return await _attendanceRepository.getAttendanceRecords(
        limit: limit,
        startDate: startDate,
        endDate: endDate,
      );
    } catch (e) {
      throw Exception('Failed to get attendance records: $e');
    }
  }

  @override
  Future<List<AttendanceRecord>> getStudentAttendanceRecords(
    String studentId, {
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      _validateDateRange(startDate, endDate);
      return await _attendanceRepository.getStudentAttendanceRecords(
        studentId,
        limit: limit,
        startDate: startDate,
        endDate: endDate,
      );
    } catch (e) {
      throw Exception('Failed to get student attendance records: $e');
    }
  }

  @override
  Future<Map<String, int>> getAttendanceStats() async {
    try {
      return await _attendanceRepository.getAttendanceStats();
    } catch (e) {
      throw Exception('Failed to get attendance statistics: $e');
    }
  }

  @override
  Future<int> getTodayAttendanceCount() async {
    try {
      return await _attendanceRepository.getTodayAttendanceCount();
    } catch (e) {
      throw Exception('Failed to get today\'s attendance count: $e');
    }
  }

  @override
  Future<int> getUniqueStudentsCount() async {
    try {
      return await _attendanceRepository.getUniqueStudentsCount();
    } catch (e) {
      throw Exception('Failed to get unique students count: $e');
    }
  }

  // Private helper methods
  void _validateDateRange(DateTime? startDate, DateTime? endDate) {
    if (startDate == null || endDate == null) {
      return;
    }

    if (!DateTimeHelper.isValidDateRange(startDate, endDate)) {
      if (startDate.isAfter(endDate)) {
        throw Exception('Start date cannot be after end date');
      } else {
        throw Exception('Date range cannot exceed 365 days');
      }
    }
  }
}
