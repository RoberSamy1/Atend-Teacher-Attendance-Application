import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/attendance_record.dart';
import '../models/student.dart';
import 'supabase_service.dart';

class AttendanceService {
  static const String _attendanceTable = 'attendance_records';
  static const String _studentsTable = 'students';
  static const String _teachersTable = 'teachers';
  static const String _subjectsTable = 'subjects';

  // Record attendance for a student
  static Future<AttendanceRecord> recordAttendance(
    String studentId, {
    String? studentName,
    String? location,
  }) async {
    try {
      // Validate input
      if (studentId.trim().isEmpty) {
        throw Exception('Student ID cannot be empty');
      }

      // Get current authenticated user
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher information based on authenticated user
      final teacherResponse = await SupabaseService.client
          .from(_teachersTable)
          .select('id, name')
          .eq('auth_user_id', user.id)
          .single();

      final teacherId = teacherResponse['id'];
      if (teacherId == null || teacherId.toString().isEmpty) {
        throw Exception('Teacher not found for authenticated user');
      }

      // Get current active subject for this teacher
      final subjectResponse = await SupabaseService.client
          .from('teacher_dashboard_view')
          .select('subject_id, class_id, subject_name')
          .eq('auth_user_id', user.id)
          .limit(1)
          .single();

      final subjectId = subjectResponse['subject_id'];
      var classId = subjectResponse['class_id'];

      if (subjectId == null || subjectId.toString().isEmpty) {
        throw Exception('No active subject found for teacher');
      }

      // Simply set class_id to null if it's empty, null, or contains 'null'
      // Remove all validation - just handle null/empty cases
      if (classId == null ||
          classId.toString().trim().isEmpty ||
          classId.toString().trim().toLowerCase() == 'null') {
        classId = null;
        print('Debug - Class ID is null/empty, will be excluded from records');
      } else {
        print('Debug - Using class_id: $classId');
      }

      // Find or create student record
      Student student;
      try {
        student = await _findStudentByStudentId(studentId);
        print('Debug - Found existing student: ${student.name}');
      } catch (e) {
        print('Debug - Student not found, need to create: $e');
        if (studentName != null && studentName.isNotEmpty) {
          // Create student without class_id to avoid any validation issues
          student = await _createStudent(studentId, studentName);
        } else {
          throw Exception(
              'Student not found with ID: $studentId. Please provide student name to create new record.');
        }
      }

      // Validate student exists
      if (student.studentId.isEmpty) {
        throw Exception('Invalid student ID');
      }

      // Check if attendance already recorded today for this subject
      final today = DateTime.now();
      final todayDateString = today.toIso8601String().split('T')[0];

      final existingAttendance = await SupabaseService.client
          .from(_attendanceTable)
          .select('id')
          .eq('student_id', student.studentId)
          .eq('subject_id', subjectId)
          .eq('attendance_date', todayDateString)
          .maybeSingle();

      if (existingAttendance != null) {
        throw Exception(
            'Attendance already recorded for ${student.name} today in this subject');
      }

      // Prepare attendance data - simplified approach
      final attendanceData = {
        'student_id': student.studentId,
        'student_name': student.name,
        'teacher_id': teacherId,
        'subject_id': subjectId,
        'status': 'present',
        'attendance_date': todayDateString,
        'location': location ?? 'Campus',
        'created_at': DateTime.now().toIso8601String(),
      };

      // Only add class_id if it's not null and not empty
      if (classId != null) {
        attendanceData['class_id'] = classId;
        print('Debug - Adding class_id to attendance: $classId');
      } else {
        print('Debug - Skipping class_id in attendance record');
      }

      print('Debug - Final attendance data: $attendanceData');

      final response = await SupabaseService.insert(
        table: _attendanceTable,
        data: attendanceData,
      );

      return AttendanceRecord.fromJson({
        ...response,
        'student_name': student.name,
        'student_id_text': student.studentId,
      });
    } catch (e) {
      print('Debug - Full error in recordAttendance: $e');
      throw Exception(
          'Failed to record attendance: ${e.toString().replaceAll('Exception: ', '')}');
    }
  }

  // Get all attendance records for authenticated teacher
  static Future<List<AttendanceRecord>> getAttendanceRecords({
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher ID first
      final teacherResponse = await SupabaseService.client
          .from(_teachersTable)
          .select('id')
          .eq('auth_user_id', user.id)
          .single();

      final teacherId = teacherResponse['id'];

      var query = SupabaseService.client
          .from(_attendanceTable)
          .select('''
            *,
            students(student_id, name),
            subjects(subject_name)
          ''')
          .eq('teacher_id', teacherId)
          .order('created_at', ascending: false);

      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;

      // Filter results in Dart instead of database
      var filteredResponse = response;

      if (startDate != null || endDate != null) {
        filteredResponse = response.where((record) {
          final attendanceDate = DateTime.tryParse(record['attendance_date']);
          if (attendanceDate == null) return false;

          bool matchesStart = startDate == null ||
              attendanceDate
                  .isAfter(startDate.subtract(const Duration(days: 1)));
          bool matchesEnd = endDate == null ||
              attendanceDate.isBefore(endDate.add(const Duration(days: 1)));

          return matchesStart && matchesEnd;
        }).toList();
      }

      return filteredResponse.map<AttendanceRecord>((json) {
        return AttendanceRecord.fromJson({
          ...json,
          'student_name': json['students']?['name'] ?? '',
          'student_id_text': json['students']?['student_id'] ?? '',
          'subject_name': json['subjects']?['subject_name'] ?? '',
        });
      }).toList();
    } catch (e) {
      throw Exception('Failed to get attendance records: $e');
    }
  }

  // Get attendance records for a specific student
  static Future<List<AttendanceRecord>> getStudentAttendanceRecords(
    String studentId, {
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      var query = SupabaseService.client
          .from(_attendanceTable)
          .select('''
            *,
            students!inner(student_id, name),
            subjects!inner(subject_name)
          ''')
          .eq('student_id', studentId) // Use text student_id directly
          .order('created_at', ascending: false);

      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;

      // Filter results in Dart instead of database
      var filteredResponse = response;

      if (startDate != null || endDate != null) {
        filteredResponse = response.where((record) {
          final attendanceDate = DateTime.tryParse(record['attendance_date']);
          if (attendanceDate == null) return false;

          bool matchesStart = startDate == null ||
              attendanceDate
                  .isAfter(startDate.subtract(const Duration(days: 1)));
          bool matchesEnd = endDate == null ||
              attendanceDate.isBefore(endDate.add(const Duration(days: 1)));

          return matchesStart && matchesEnd;
        }).toList();
      }

      return filteredResponse.map<AttendanceRecord>((json) {
        return AttendanceRecord.fromJson({
          ...json,
          'student_name': json['students']['name'],
          'student_id_text': json['students']['student_id'],
        });
      }).toList();
    } catch (e) {
      throw Exception('Failed to get student attendance records: $e');
    }
  }

  // Get attendance statistics for authenticated teacher
  static Future<Map<String, int>> getAttendanceStats() async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher ID first
      final teacherResponse = await SupabaseService.client
          .from(_teachersTable)
          .select('id')
          .eq('auth_user_id', user.id)
          .single();

      final teacherId = teacherResponse['id'];

      final response = await SupabaseService.client
          .from(_attendanceTable)
          .select('status')
          .eq('teacher_id', teacherId);

      final stats = <String, int>{
        'total': response.length,
        'present': 0,
        'absent': 0,
        'late': 0,
      };

      for (final record in response) {
        final status = record['status'] as String? ?? 'present';
        stats[status] = (stats[status] ?? 0) + 1;
      }

      return stats;
    } catch (e) {
      throw Exception('Failed to get attendance statistics: $e');
    }
  }

  // Get today's attendance count for authenticated teacher
  static Future<int> getTodayAttendanceCount() async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher ID first
      final teacherResponse = await SupabaseService.client
          .from(_teachersTable)
          .select('id')
          .eq('auth_user_id', user.id)
          .single();

      final teacherId = teacherResponse['id'];
      final today = DateTime.now().toIso8601String().split('T')[0];

      final response = await SupabaseService.client
          .from(_attendanceTable)
          .select('id')
          .eq('teacher_id', teacherId)
          .eq('attendance_date', today);

      return response.length;
    } catch (e) {
      throw Exception('Failed to get today\'s attendance count: $e');
    }
  }

  // Get unique students count for authenticated teacher
  static Future<int> getUniqueStudentsCount() async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher ID first
      final teacherResponse = await SupabaseService.client
          .from(_teachersTable)
          .select('id')
          .eq('auth_user_id', user.id)
          .single();

      final teacherId = teacherResponse['id'];

      final response = await SupabaseService.client
          .from(_attendanceTable)
          .select('student_id')
          .eq('teacher_id', teacherId);

      final uniqueStudentIds = <String>{};
      for (final record in response) {
        uniqueStudentIds.add(record['student_id'] as String);
      }

      return uniqueStudentIds.length;
    } catch (e) {
      throw Exception('Failed to get unique students count: $e');
    }
  }

  // Private method to find student by student_id (text field)
  static Future<Student> _findStudentByStudentId(String studentId) async {
    final response = await SupabaseService.client
        .from(_studentsTable)
        .select('*')
        .eq('student_id', studentId)
        .single();

    return Student.fromJson(response);
  }

  // Simplified private method to create a new student
  static Future<Student> _createStudent(String studentId, String name) async {
    try {
      final studentData = {
        'student_id': studentId,
        'name': name,
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      };

      print('Debug - Creating student: $studentId, Name: $name');
      print('Debug - Student data: $studentData');

      final response = await SupabaseService.insert(
        table: _studentsTable,
        data: studentData,
      );

      print('Debug - Student created successfully with ID: ${response['id']}');
      return Student.fromJson(response);
    } catch (e) {
      print('Debug - Error in _createStudent: $e');
      throw Exception('Failed to create student: ${e.toString()}');
    }
  }

  // Get all students for authenticated teacher's classes
  static Future<List<Student>> getAllStudents() async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get students from teacher's classes
      final response =
          await SupabaseService.client.from(_studentsTable).select('''
            *,
            classes!inner(
              id,
              name,
              teacher_id,
              teachers!inner(auth_user_id)
            )
          ''').eq('classes.teachers.auth_user_id', user.id).order('name');

      return response
          .map((json) => Student.fromJson({
                ...json,
                'class_name': json['classes']?['name'],
                'class_id': json['classes']?['id'],
              }))
          .toList();
    } catch (e) {
      // Fallback: get all students if the above fails
      try {
        final response =
            await SupabaseService.client.from(_studentsTable).select('''
              *,
              classes (
                id,
                name
              )
            ''').order('name');

        return response
            .map((json) => Student.fromJson({
                  ...json,
                  'class_name': json['classes']?['name'],
                  'class_id': json['classes']?['id'],
                }))
            .toList();
      } catch (fallbackError) {
        throw Exception('Failed to get students: $e');
      }
    }
  }

  // Add or update student - simplified without class_id validation
  static Future<Student> addOrUpdateStudent(Student student) async {
    try {
      // Validate required fields
      if (student.studentId.isEmpty) {
        throw Exception('Student ID cannot be empty');
      }
      if (student.name.isEmpty) {
        throw Exception('Student name cannot be empty');
      }

      // Check if student exists
      try {
        final existingStudent =
            await _findStudentByStudentId(student.studentId);

        // Update existing student
        final updatedData = {
          'name': student.name,
          'email': student.email,
          'phone': student.phone,
          'department': student.department,
          'year': student.year,
          'updated_at': DateTime.now().toIso8601String(),
        };

        // Only add class_id if it's not null or empty
        if (student.classId != null && student.classId!.trim().isNotEmpty) {
          updatedData['class_id'] = student.classId!.trim();
        }

        final response = await SupabaseService.update(
          table: _studentsTable,
          data: updatedData,
          id: existingStudent.id,
        );

        return Student.fromJson(response);
      } catch (e) {
        // Student doesn't exist, create new one
        return await _createStudent(student.studentId, student.name);
      }
    } catch (e) {
      throw Exception('Failed to add or update student: $e');
    }
  }

  // Get current teacher's active subject/class info
  static Future<Map<String, dynamic>?> getCurrentTeacherInfo() async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) return null;

      final response = await SupabaseService.client
          .from('teacher_dashboard_view')
          .select('*')
          .eq('auth_user_id', user.id)
          .limit(1)
          .maybeSingle();

      return response;
    } catch (e) {
      print('Error getting teacher info: $e');
      return null;
    }
  }

  static Future<List<Student>> searchStudents(String query) async {
    try {
      final user = SupabaseService.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher's info
      final teacherResponse = await SupabaseService.client
          .from(_teachersTable)
          .select('id')
          .eq('auth_user_id', user.id)
          .single();

      final teacherId = teacherResponse['id'];

      final subjectsResponse = await SupabaseService.client
          .from('teacher_subject_assignments')
          .select('subject_id, class_id')
          .eq('teacher_id', teacherId)
          .eq('status', 'active');

      if (subjectsResponse.isEmpty) {
        return [];
      }

      // Extract class IDs from subjects - only non-empty ones
      final classIds = subjectsResponse
          .map((s) => s['class_id']?.toString())
          .where(
              (id) => id != null && id.isNotEmpty && id.toLowerCase() != 'null')
          .toList();

      if (classIds.isEmpty) {
        return [];
      }

      // Search students in teacher's assigned classes
      final response = await SupabaseService.client
          .from('students')
          .select('''
            *,
            classes!inner (
              id,
              name
            )
          ''')
          .filter('class_id', 'in', '(${classIds.join(',')})')
          .or('student_id.ilike.%${query}%,name.ilike.%${query}%')
          .order('name');

      // Map response to Student objects
      return response
          .map((json) => Student.fromJson({
                ...json,
                'class_name': json['classes']['name'],
              }))
          .toList();
    } catch (e) {
      throw Exception('Failed to search students: $e');
    }
  }
}
