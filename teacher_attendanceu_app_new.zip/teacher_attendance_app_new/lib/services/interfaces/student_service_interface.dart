import 'package:atten/models/student.dart';


abstract class IStudentService {
  Future<List<Student>> getAllStudents();
  Future<List<Student>> searchStudents(String query);
  Future<Student> addOrUpdateStudent(Student student);
}
