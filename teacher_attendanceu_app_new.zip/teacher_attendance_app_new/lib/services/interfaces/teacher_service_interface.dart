abstract class ITeacherService {
  Future<Map<String, dynamic>?> getCurrentTeacherInfo();
  Future<String> getTeacherId();
  Future<List<Map<String, dynamic>>> getTeacherSubjects();
  Future<bool> isTeacherActive();
}
