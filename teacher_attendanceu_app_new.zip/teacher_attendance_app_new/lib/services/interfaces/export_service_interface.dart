abstract class IExportService {
  Future<String> exportToExcel(List<Map<String, dynamic>> data, String fileName);
  Future<String> exportToCsv(List<Map<String, dynamic>> data, String fileName);
  Future<bool> saveFile(String content, String fileName, String fileType);
}
