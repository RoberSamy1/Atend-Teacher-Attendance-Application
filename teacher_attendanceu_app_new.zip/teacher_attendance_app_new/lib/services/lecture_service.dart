import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/lecture.dart';

class LectureService {
  static final SupabaseClient _client = Supabase.instance.client;

  // Helper method to validate UUID format
  static bool _isValidUUID(String? uuid) {
    if (uuid == null) return false;
    const pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    return RegExp(pattern, caseSensitive: false).hasMatch(uuid);
  }

  // Create a new lecture
  static Future<Lecture> createLecture({
    required String name,
    required String subjectId,  // UUID
    required String teacherId,  // UUID
    required DateTime date,
  }) async {
    try {
      // Validate UUID format
      if (!_isValidUUID(subjectId) || !_isValidUUID(teacherId)) {
        throw Exception('Invalid UUID format for subject_id or teacher_id');
      }

      final data = {
        'name': name,
        'subject_id': subjectId,
        'teacher_id': teacherId,
        'date': date.toIso8601String().split('T')[0], // Format as YYYY-MM-DD
      };

      // Check for existing lecture with same name, subject and date
      final existingLecture = await _client
          .from('lectures')
          .select()
          .eq('subject_id', subjectId)
          .eq('name', name)
          .eq('date', date.toIso8601String().split('T')[0])
          .maybeSingle();

      if (existingLecture != null) {
        throw Exception('A lecture with this name already exists for this subject on the same date');
      }

      final response = await _client
          .from('lectures')
          .insert(data)
          .select()
          .single();

      return Lecture(
        id: response['id'],
        name: response['name'],
        subjectId: response['subject_id'],
        teacherId: response['teacher_id'],
        date: DateTime.parse(response['date']),
        createdAt: DateTime.parse(response['created_at']),
      );
    } catch (e) {
      throw Exception('Failed to create lecture: $e');
    }
  }

  // Get all lectures for a teacher with details using teacher_dashboard_view
  static Future<List<Map<String, dynamic>>> getLecturesWithDetails(String teacherId) async {
    try {
      if (!_isValidUUID(teacherId)) {
        throw Exception('Invalid teacher ID format');
      }

      final response = await _client
          .from('lectures')
          .select('''
            id,
            name,
            subject_id,
            teacher_id,
            date,
            created_at,
            subjects!inner (
              id,
              subject_name,
              subject_code
            ),
            attendance_records (
              id,
              status
            )
          ''')
          .eq('teacher_id', teacherId)
          .order('date', ascending: false);

      final results = List<Map<String, dynamic>>.from(response);
      return results.map((lecture) {
        final subject = lecture['subjects'];
        final attendanceRecords = lecture['attendance_records'] as List;
        
        final presentCount = attendanceRecords.where((record) => 
          record['status'] == 'present'
        ).length;

        return {
          ...lecture,
          'subject_name': subject['subject_name'],
          'subject_code': subject['subject_code'],
          'attendance_count': attendanceRecords.length,
          'present_count': presentCount,
          'absent_count': attendanceRecords.length - presentCount,
        };
      }).toList();
    } catch (e) {
      throw Exception('Failed to get lectures with details: $e');
    }
  }

  // Get a specific lecture by ID with all its details
  static Future<Map<String, dynamic>> getLecture(String id) async {
    try {
      if (!_isValidUUID(id)) {
        throw Exception('Invalid lecture ID format');
      }

      final response = await _client
          .from('lectures')
          .select('''
            id,
            name,
            subject_id,
            teacher_id,
            date,
            created_at,
            subjects!inner (
              id,
              subject_name,
              subject_code,
              department
            ),
            attendance_records (
              id,
              student_id,
              student_name,
              status,
              timestamp,
              location
            )
          ''')
          .eq('id', id)
          .single();

      final attendanceRecords = response['attendance_records'] as List;
      final subject = response['subjects'] as Map<String, dynamic>;
      
      final presentCount = attendanceRecords.where((record) => 
        record['status'] == 'present'
      ).length;

      return {
        ...response,
        'subject_name': subject['subject_name'],
        'subject_code': subject['subject_code'],
        'department': subject['department'],
        'attendance_count': attendanceRecords.length,
        'present_count': presentCount,
        'absent_count': attendanceRecords.length - presentCount,
      };
    } catch (e) {
      throw Exception('Failed to get lecture: $e');
    }
  }

  // Get lectures for a specific subject
  static Future<List<Lecture>> getSubjectLectures(String subjectId) async {
    try {
      if (!_isValidUUID(subjectId)) {
        throw Exception('Invalid subject ID format');
      }

      final response = await _client
          .from('lectures')
          .select()
          .eq('subject_id', subjectId)
          .order('date', ascending: false);

      return List<Map<String, dynamic>>.from(response)
          .map((data) => Lecture.fromMap(data))
          .toList();
    } catch (e) {
      throw Exception('Failed to get subject lectures: $e');
    }
  }
}
