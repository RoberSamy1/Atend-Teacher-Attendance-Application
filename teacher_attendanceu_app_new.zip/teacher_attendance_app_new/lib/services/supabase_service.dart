import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:collection/collection.dart';

class SupabaseService {
  static final SupabaseClient _client = Supabase.instance.client;

  static SupabaseClient get client => _client;

  // Check if user is authenticated
  static bool get isAuthenticated => _client.auth.currentUser != null;

  // Get current user
  static User? get currentUser => _client.auth.currentUser;

  // Initialize Supabase (called in main.dart)
  static Future<void> initialize({
    required String url,
    required String anonKey,
  }) async {
    await Supabase.initialize(
      url: url,
      anonKey: anonKey,
    );
  }

  // Generic method to insert data
  static Future<Map<String, dynamic>> insert({
    required String table,
    required Map<String, dynamic> data,
  }) async {
    try {
      // Add timestamps for tables that need them
      final needsTimestamps = ['teachers', 'subjects', 'classes', 'students'];
      if (needsTimestamps.contains(table)) {
        final now = DateTime.now().toIso8601String();
        data['created_at'] = now;
        data['updated_at'] = now;
      }

      // Special handling for lectures table
      if (table == 'lectures') {
        if (!_isValidUUID(data['subject_id']) || !_isValidUUID(data['teacher_id'])) {
          throw Exception('Invalid UUID format for subject_id or teacher_id');
        }

        // Check unique constraint
        final existingLecture = await _client
            .from('lectures')
            .select()
            .eq('subject_id', data['subject_id'])
            .eq('name', data['name'])
            .eq('date', data['date'])
            .maybeSingle();

        if (existingLecture != null) {
          throw Exception('A lecture with this name already exists for this subject on the same date');
        }
      }

      final response = await _client.from(table).insert(data).select().single();
      return response;
    } catch (e) {
      throw Exception('Failed to insert data into $table: $e');
    }
  }

  // Generic method to select data
  static Future<List<Map<String, dynamic>>> select({
    required String table,
    String? columns,
    String? filter,
    String? orderBy,
    int? limit,
  }) async {
    try {
      // Don't assign back to the same variable - build the query step by step
      dynamic query = _client.from(table).select(columns ?? '*');

      // Apply filters first
      if (filter != null) {
        // This is a simplified filter implementation
        // In a real app, you'd want more sophisticated filtering
        query = query.eq('student_id', filter);
      }

      // Apply ordering after filters
      if (orderBy != null) {
        query = query.order(orderBy, ascending: false);
      }

      // Apply limit last
      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to select data from $table: $e');
    }
  }

  // Generic method to update data
  static Future<Map<String, dynamic>> update({
    required String table,
    required Map<String, dynamic> data,
    required String id,
  }) async {
    try {
      final response =
          await _client.from(table).update(data).eq('id', id).select().single();
      return response;
    } catch (e) {
      throw Exception('Failed to update data in $table: $e');
    }
  }

  // Generic method to delete data
  static Future<void> delete({
    required String table,
    required String id,
  }) async {
    try {
      await _client.from(table).delete().eq('id', id);
    } catch (e) {
      throw Exception('Failed to delete data from $table: $e');
    }
  }

  // Method to get data with date range filter
  static Future<List<Map<String, dynamic>>> selectWithDateRange({
    required String table,
    String? columns,
    DateTime? startDate,
    DateTime? endDate,
    String? orderBy,
    int? limit,
  }) async {
    try {
      // Use dynamic type to handle different builder types
      dynamic query = _client.from(table).select(columns ?? '*');

      // Apply all filters first
      if (startDate != null) {
        query = query.gte('timestamp', startDate.toIso8601String());
      }

      if (endDate != null) {
        query = query.lte('timestamp', endDate.toIso8601String());
      }

      // Apply ordering after all filters
      if (orderBy != null) {
        query = query.order(orderBy, ascending: false);
      }

      // Apply limit last
      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to select data from $table with date range: $e');
    }
  }

  // Method to get attendance statistics
  static Future<Map<String, int>> getAttendanceStats() async {
    try {
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      // Get today's attendance count
      final todayAttendance = await _client
          .from('attendance_records')
          .select('id')
          .gte('timestamp', startOfDay.toIso8601String())
          .lt('timestamp', endOfDay.toIso8601String());

      // Get total attendance count
      final totalAttendance =
          await _client.from('attendance_records').select('id');

      // Get unique students count using distinct
      final uniqueStudents = await _client
          .from('attendance_records')
          .select('student_id')
          .order('student_id');

      final uniqueStudentIds = <String>{};
      for (final record in uniqueStudents) {
        uniqueStudentIds.add(record['student_id'] as String);
      }

      return {
        'today': todayAttendance.length,
        'total': totalAttendance.length,
        'unique_students': uniqueStudentIds.length,
      };
    } catch (e) {
      throw Exception('Failed to get attendance statistics: $e');
    }
  }

  // Enhanced method to get filtered attendance records
  static Future<List<Map<String, dynamic>>> getAttendanceRecords({
    String? studentId,
    DateTime? startDate,
    DateTime? endDate,
    String orderBy = 'timestamp',
    bool ascending = false,
    int? limit,
  }) async {
    try {
      dynamic query = _client.from('attendance_records').select('*');

      // Apply all filters first
      if (studentId != null) {
        query = query.eq('student_id', studentId);
      }

      if (startDate != null) {
        query = query.gte('timestamp', startDate.toIso8601String());
      }

      if (endDate != null) {
        query = query.lte('timestamp', endDate.toIso8601String());
      }

      // Apply ordering after filters
      query = query.order(orderBy, ascending: ascending);

      // Apply limit last
      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception('Failed to get attendance records: $e');
    }
  }

  // Method to get subjects for a specific teacher using the teacher_dashboard_view
  static Future<List<Map<String, dynamic>>> getTeacherSubjects(
      String teacherId) async {
    try {
      // Validate UUID
      if (!_isValidUUID(teacherId)) {
        throw Exception('Invalid teacher ID format');
      }

      final response = await _client
          .from("teacher_dashboard_view")
          .select('''
            teacher_id,
            auth_user_id,
            teacher_name,
            subject_id,
            subject_name,
            class_id,
            class_name,
            academic_year,
            semester,
            lecture_count,
            total_students
          ''')
          .eq("teacher_id", teacherId);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception("Failed to get teacher's subjects: $e");
    }
  }

  // Helper method to validate UUID format
  static bool _isValidUUID(String? uuid) {
    if (uuid == null) return false;
    const pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    return RegExp(pattern, caseSensitive: false).hasMatch(uuid);
  }

  // Method to get student attendance summary with present/absent counts
  static Future<List<Map<String, dynamic>>> getStudentAttendanceSummary({
    String? studentId,
    String? subjectId,
  }) async {
    try {
      dynamic query = _client.from("student_attendance_summary").select("*");

      if (studentId != null) {
        query = query.eq("student_id", studentId);
      }
      if (subjectId != null) {
        query = query.eq("subject_id", subjectId);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception("Failed to get student attendance summary: $e");
    }
  }

  // Method to record attendance for a specific class and subject
  static Future<Map<String, dynamic>> recordAttendance({
    required String studentId,
    required String studentName,
    required String classId,
    required String subjectId,
    String? lectureId,
    String status = 'present',
    String location = 'Campus',
  }) async {
    try {
      // Validate UUIDs


      // Get current user (teacher)
      final user = currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Get teacher ID from auth_user_id
      final teacherResponse = await _client
          .from('teachers')
          .select('id')
          .eq('auth_user_id', user.id)
          .single();
      
      final teacherId = teacherResponse['id'];

      final data = {
        "student_id": studentId,
        "student_name": studentName,
        "teacher_id": teacherId,
        "class_id": classId,
        "subject_id": subjectId,
        "status": status,
        "location": location,
        "timestamp": DateTime.now().toIso8601String(),
        "attendance_date": DateTime.now().toIso8601String().split('T')[0],
      };

      if (lectureId != null) {
        data["lecture_id"] = lectureId;
      }

      final response = await _client
          .from("attendance_records")
          .insert(data)
          .select()
          .single();
      return response;
    } catch (e) {
      throw Exception("Failed to record attendance: $e");
    }
  }

  // Method to get lectures for a specific subject
  static Future<List<Map<String, dynamic>>> getSubjectLectures(String subjectId) async {
    try {
      final response = await _client
          .from("lectures")
          .select("*")
          .eq("subject_id", subjectId)
          .order("date", ascending: false);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception("Failed to get subject lectures: $e");
    }
  }

  // Method to get attendance records for a specific lecture
  static Future<List<Map<String, dynamic>>> getLectureAttendance(String lectureId) async {
    try {
      final response = await _client
          .from("attendance_records")
          .select("*")
          .eq("lecture_id", lectureId)
          .order("timestamp", ascending: false);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      throw Exception("Failed to get lecture attendance: $e");
    }
  }

  // Method to get all lectures with subject details and attendance count
  static Future<List<Map<String, dynamic>>> getAllLecturesWithDetails() async {
    try {
      final response = await _client.rpc(
        'get_lectures_with_details',
        params: {
          'teacher_id': currentUser?.id,
        },
      );
      
      final lectures = List<Map<String, dynamic>>.from(response);
      return lectures.map((lecture) {
        return {
          ...lecture,
          'attendance_count': lecture['attendance_count'] ?? 0,
        };
      }).toList();
    } catch (e) {
      throw Exception("Failed to get lectures with details: $e");
    }
  }
}
