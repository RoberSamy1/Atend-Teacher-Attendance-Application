import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'supabase_service.dart';

class ExportService {
  // Request appropriate permissions based on Android version
  static Future<bool> _requestStoragePermission() async {
    if (Platform.isAndroid) {
      // For Android 13+ (API 33+), we need different permissions
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      
      if (androidInfo.version.sdkInt >= 33) {
        // Android 13+ - Request media permissions
        final status = await [
          Permission.photos,
          Permission.videos,
          Permission.audio,
        ].request();
        
        return status.values.every((status) => 
          status == PermissionStatus.granted || 
          status == PermissionStatus.limited
        );
      } else if (androidInfo.version.sdkInt >= 30) {
        // Android 11+ - Request manage external storage for full access
        if (await Permission.manageExternalStorage.isGranted) {
          return true;
        }
        
        final status = await Permission.manageExternalStorage.request();
        if (status == PermissionStatus.granted) {
          return true;
        }
        
        // Fallback to storage permission
        return await Permission.storage.request().isGranted;
      } else {
        // Android 10 and below
        final status = await Permission.storage.request();
        return status == PermissionStatus.granted;
      }
    }
    return true; // For iOS or other platforms
  }

  // Get the appropriate directory for saving files
  static Future<Directory?> _getSaveDirectory() async {
    if (Platform.isAndroid) {
      try {
        // Create app-specific folder in Downloads
        final downloadDir = Directory('/storage/emulated/0/Download/Teacher_Attendance');
        if (!await downloadDir.exists()) {
          await downloadDir.create(recursive: true);
        }
        return downloadDir;
      } catch (e) {
        try {
          // Fallback: Create app folder in Documents
          final documentsDir = Directory('/storage/emulated/0/Documents/Teacher_Attendance');
          if (!await documentsDir.exists()) {
            await documentsDir.create(recursive: true);
          }
          return documentsDir;
        } catch (e2) {
          // Final fallback to external storage directory with app folder
          final externalDir = await getExternalStorageDirectory();
          if (externalDir != null) {
            final appDir = Directory('${externalDir.path}/Teacher_Attendance');
            if (!await appDir.exists()) {
              await appDir.create(recursive: true);
            }
            return appDir;
          }
          return await getApplicationDocumentsDirectory();
        }
      }
    } else {
      // For iOS and other platforms - create app folder in documents
      final documentsDir = await getApplicationDocumentsDirectory();
      final appDir = Directory('${documentsDir.path}/Teacher_Attendance');
      if (!await appDir.exists()) {
        await appDir.create(recursive: true);
      }
      return appDir;
    }
  }

  // Export attendance data to Excel
  static Future<String> exportAttendanceToExcel({
    required String subjectId,
    required String subjectName,
    String? classId,
    String? className,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      // Request storage permission
      final hasPermission = await _requestStoragePermission();
      if (!hasPermission) {
        throw Exception('Storage permission is required to export files. Please grant permission in app settings.');
      }

      // Get attendance records
      final records = await SupabaseService.getAttendanceRecords(
        startDate: startDate,
        endDate: endDate,
      );

      // Filter records for this subject
      final filteredRecords = records.where((record) {
        return record['subject_id'] == subjectId;
      }).toList();

      // Create Excel workbook
      final excel = Excel.createExcel();
      final sheet = excel['Attendance Report'];

      // Add headers
      sheet.cell(CellIndex.indexByString('A1')).value = 'Student ID';
      sheet.cell(CellIndex.indexByString('B1')).value = 'Student Name';
      sheet.cell(CellIndex.indexByString('C1')).value = 'Date';
      sheet.cell(CellIndex.indexByString('D1')).value = 'Time';
      sheet.cell(CellIndex.indexByString('E1')).value = 'Status';
      sheet.cell(CellIndex.indexByString('F1')).value = 'Subject';
      sheet.cell(CellIndex.indexByString('G1')).value = 'Class';

      // Style headers
      for (int col = 0; col < 7; col++) {
        final cell = sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: 0));
        cell.cellStyle = CellStyle(
          bold: true,
          backgroundColorHex: '#1976D2', // Blue 700
          fontColorHex: '#FFFFFF', // White
        );
      }

      // Add data rows
      for (int i = 0; i < filteredRecords.length; i++) {
        final record = filteredRecords[i];
        final rowIndex = i + 1;
        final timestamp = DateTime.parse(record['timestamp']);

        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: rowIndex))
            .value = record['student_id'];
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 1, rowIndex: rowIndex))
            .value = record['student_name'] ?? 'Unknown';
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: rowIndex))
            .value = timestamp.toLocal().toString().substring(0, 10);
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 3, rowIndex: rowIndex))
            .value = timestamp.toLocal().toString().substring(11, 16);
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 4, rowIndex: rowIndex))
            .value = record['status'];
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 5, rowIndex: rowIndex))
            .value = subjectName;
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 6, rowIndex: rowIndex))
            .value = className ?? 'N/A';

        // Style status cell based on value
        final statusCell = sheet.cell(
            CellIndex.indexByColumnRow(columnIndex: 4, rowIndex: rowIndex));
        if (record['status'] == 'present') {
          statusCell.cellStyle = CellStyle(
            backgroundColorHex: '#C8E6C9', // Light green
            fontColorHex: '#2E7D32', // Dark green
          );
        } else {
          statusCell.cellStyle = CellStyle(
            backgroundColorHex: '#FFCDD2', // Light red
            fontColorHex: '#C62828', // Dark red
          );
        }
      }

      // Auto-fit columns
      for (int col = 0; col < 7; col++) {
        sheet.setColAutoFit(col);
      }

      // Get the save directory
      final directory = await _getSaveDirectory();
      if (directory == null) {
        throw Exception('Could not access storage directory');
      }

      // Ensure directory exists
      if (!await directory.exists()) {
        await directory.create(recursive: true);
      }

      // Create filename with timestamp
      final now = DateTime.now();
      final dateStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      final timeStr = '${now.hour.toString().padLeft(2, '0')}-${now.minute.toString().padLeft(2, '0')}';
      final filename = 'attendance_${subjectName.replaceAll(RegExp(r'[^\w\s-]'), '').replaceAll(' ', '_')}_${dateStr}_$timeStr.xlsx';

      final filePath = '${directory.path}/$filename';
      final file = File(filePath);

      // Save the Excel file
      final bytes = excel.encode();
      if (bytes != null) {
        await file.writeAsBytes(bytes);
        return filePath;
      } else {
        throw Exception('Failed to encode Excel file');
      }
    } catch (e) {
      throw Exception('Failed to export attendance data: $e');
    }
  }

  // Export attendance summary to Excel
  static Future<String> exportAttendanceSummaryToExcel({
    required String subjectId,
    required String subjectName,
    String? classId,
    String? className,
  }) async {
    try {
      // Request storage permission
      final hasPermission = await _requestStoragePermission();
      if (!hasPermission) {
        throw Exception('Storage permission is required to export files. Please grant permission in app settings.');
      }

      // Get attendance summary
      final summaryData = await SupabaseService.getStudentAttendanceSummary(
        subjectId: subjectId,
      );

      // Create Excel workbook
      final excel = Excel.createExcel();
      final sheet = excel['Attendance Summary'];

      // Add headers
      sheet.cell(CellIndex.indexByString('A1')).value = 'Student ID';
      sheet.cell(CellIndex.indexByString('B1')).value = 'Student Name';
      sheet.cell(CellIndex.indexByString('C1')).value = 'Department';
      sheet.cell(CellIndex.indexByString('D1')).value = 'Year';
      sheet.cell(CellIndex.indexByString('E1')).value = 'Total Sessions';
      sheet.cell(CellIndex.indexByString('F1')).value = 'Present';
      sheet.cell(CellIndex.indexByString('G1')).value = 'Absent';
      sheet.cell(CellIndex.indexByString('H1')).value = 'Attendance %';
      sheet.cell(CellIndex.indexByString('I1')).value = 'Last Attendance';

      // Style headers
      for (int col = 0; col < 9; col++) {
        final cell = sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: 0));
        cell.cellStyle = CellStyle(
          bold: true,
          backgroundColorHex: '#1976D2', // Blue 700
          fontColorHex: '#FFFFFF', // White
        );
      }

      // Add data rows
      for (int i = 0; i < summaryData.length; i++) {
        final summary = summaryData[i];
        final rowIndex = i + 1;

        final totalSessions = (summary['total_attendance'] ?? 0) as int;
        final presentCount = (summary['present_count'] ?? 0) as int;
        final absentCount = (summary['absent_count'] ?? 0) as int;
        final attendancePercentage = totalSessions > 0
            ? (presentCount / totalSessions * 100).toStringAsFixed(1)
            : '0.0';

        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: rowIndex))
            .value = summary['student_id'];
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 1, rowIndex: rowIndex))
            .value = summary['name'] ?? 'Unknown';
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: rowIndex))
            .value = summary['department'] ?? 'N/A';
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 3, rowIndex: rowIndex))
            .value = summary['year']?.toString() ?? 'N/A';
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 4, rowIndex: rowIndex))
            .value = totalSessions;
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 5, rowIndex: rowIndex))
            .value = presentCount;
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 6, rowIndex: rowIndex))
            .value = absentCount;
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 7, rowIndex: rowIndex))
            .value = '$attendancePercentage%';
        sheet
            .cell(CellIndex.indexByColumnRow(columnIndex: 8, rowIndex: rowIndex))
            .value = summary['last_attendance'] != null
                ? DateTime.parse(summary['last_attendance'])
                    .toLocal()
                    .toString()
                    .substring(0, 16)
                : 'Never';

        // Color code attendance percentage
        final percentageCell = sheet.cell(
            CellIndex.indexByColumnRow(columnIndex: 7, rowIndex: rowIndex));
        final percentage = double.tryParse(attendancePercentage) ?? 0.0;
        if (percentage >= 75) {
          percentageCell.cellStyle = CellStyle(
            backgroundColorHex: '#C8E6C9', // Light green
            fontColorHex: '#2E7D32', // Dark green
          );
        } else if (percentage >= 50) {
          percentageCell.cellStyle = CellStyle(
            backgroundColorHex: '#FFF3E0', // Light orange
            fontColorHex: '#E65100', // Dark orange
          );
        } else {
          percentageCell.cellStyle = CellStyle(
            backgroundColorHex: '#FFCDD2', // Light red
            fontColorHex: '#C62828', // Dark red
          );
        }
      }

      // Auto-fit columns
      for (int col = 0; col < 9; col++) {
        sheet.setColAutoFit(col);
      }

      // Get the save directory
      final directory = await _getSaveDirectory();
      if (directory == null) {
        throw Exception('Could not access storage directory');
      }

      // Ensure directory exists
      if (!await directory.exists()) {
        await directory.create(recursive: true);
      }

      // Create filename with timestamp
      final now = DateTime.now();
      final dateStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      final timeStr = '${now.hour.toString().padLeft(2, '0')}-${now.minute.toString().padLeft(2, '0')}';
      final filename = 'attendance_summary_${subjectName.replaceAll(RegExp(r'[^\w\s-]'), '').replaceAll(' ', '_')}_${dateStr}_$timeStr.xlsx';

      final filePath = '${directory.path}/$filename';
      final file = File(filePath);

      // Save the Excel file
      final bytes = excel.encode();
      if (bytes != null) {
        await file.writeAsBytes(bytes);
        return filePath;
      } else {
        throw Exception('Failed to encode Excel file');
      }
    } catch (e) {
      throw Exception('Failed to export attendance summary: $e');
    }
  }
}