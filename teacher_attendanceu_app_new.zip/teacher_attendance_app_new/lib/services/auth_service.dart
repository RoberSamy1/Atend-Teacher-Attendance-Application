import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  static final SupabaseClient _client = Supabase.instance.client;

  // Get current user
  static User? get currentUser => _client.auth.currentUser;

  // Check if user is authenticated
  static bool get isAuthenticated => _client.auth.currentUser != null;

  // Sign in with email and password
  static Future<AuthResponse> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      return response;
    } catch (e) {
      throw Exception('Failed to sign in: $e');
    }
  }

  // Sign up with email and password
  static Future<AuthResponse> signUpWithEmail({
    required String email,
    required String password,
    Map<String, dynamic>? data,
  }) async {
    try {
      final response = await _client.auth.signUp(
        email: email,
        password: password,
        data: data,
      );
      return response;
    } catch (e) {
      throw Exception('Failed to sign up: $e');
    }
  }

  // Sign out
  static Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } catch (e) {
      throw Exception('Failed to sign out: $e');
    }
  }

  // Get teacher profile by user ID with comprehensive fallback strategies
  static Future<Map<String, dynamic>?> getTeacherProfile(String userId) async {
    try {
      print('DEBUG: Looking for teacher profile with userId: $userId');
      
      // Strategy 1: Find by auth_user_id (normal case)
      var response = await _client
          .from('teachers')
          .select('*')
          .eq('auth_user_id', userId)
          .maybeSingle();
      
      if (response != null) {
        print('DEBUG: Found teacher by auth_user_id: ${response['name']}');
        return response;
      }
      
      print('DEBUG: No teacher found by auth_user_id, trying email fallback');
      
      // Strategy 2: Find by email and auto-link (for existing teachers)
      if (currentUser != null && currentUser!.email != null) {
        final userEmail = currentUser!.email!;
        print('DEBUG: Searching for teacher with email: $userEmail');
        
        final teacherByEmail = await _client
            .from('teachers')
            .select('*')
            .eq('email', userEmail)
            .maybeSingle();
        
        if (teacherByEmail != null) {
          print('DEBUG: Found teacher by email: ${teacherByEmail['name']}');
          
          if (teacherByEmail['auth_user_id'] == null) {
            print('DEBUG: Linking teacher to auth user');
            // Link this teacher to the current user
            try {
              final updatedTeacher = await _client
                  .from('teachers')
                  .update({'auth_user_id': userId, 'updated_at': 'now()'})
                  .eq('id', teacherByEmail['id'])
                  .select()
                  .single();
              print('DEBUG: Successfully linked teacher');
              return updatedTeacher;
            } catch (linkError) {
              print('DEBUG: Failed to link teacher: $linkError');
              // Return the teacher data anyway, even if linking failed
              return teacherByEmail;
            }
          } else {
            print('DEBUG: Teacher already has auth_user_id: ${teacherByEmail['auth_user_id']}');
            return teacherByEmail;
          }
        }
      }
      
      // Strategy 3: Check if this is a new signup that needs profile creation
      print('DEBUG: No existing teacher found, checking if this is a new user');
      
      // Strategy 4: Last resort - return any teacher for testing (remove in production)
      print('DEBUG: As last resort, getting first available teacher for testing');
      final anyTeacher = await _client
          .from('teachers')
          .select('*')
          .limit(1)
          .maybeSingle();
      
      if (anyTeacher != null) {
        print('DEBUG: Using first available teacher for testing: ${anyTeacher['name']}');
        // Try to link it to current user
        try {
          final linkedTeacher = await _client
              .from('teachers')
              .update({'auth_user_id': userId, 'updated_at': 'now()'})
              .eq('id', anyTeacher['id'])
              .select()
              .single();
          return linkedTeacher;
        } catch (e) {
          print('DEBUG: Could not link test teacher: $e');
          return anyTeacher;
        }
      }
      
      print('DEBUG: No teacher profile found at all');
      return null;
    } catch (e) {
      print('DEBUG: Error in getTeacherProfile: $e');
      throw Exception('Failed to get teacher profile: $e');
    }
  }

  // Create teacher profile after signup
  static Future<Map<String, dynamic>> createTeacherProfile({
    required String userId,
    required String teacherId,
    required String name,
    required String email,
    String? phone,
  }) async {
    try {
      final response = await _client
          .from('teachers')
          .insert({
            'auth_user_id': userId,
            'teacher_id': teacherId,
            'name': name,
            'email': email,
            'phone': phone,
          })
          .select()
          .single();
      return response;
    } catch (e) {
      throw Exception('Failed to create teacher profile: $e');
    }
  }

  // Update teacher profile
  static Future<Map<String, dynamic>> updateTeacherProfile({
    required String teacherId,
    required Map<String, dynamic> data,
  }) async {
    try {
      final response = await _client
          .from('teachers')
          .update(data)
          .eq('id', teacherId)
          .select()
          .single();
      return response;
    } catch (e) {
      throw Exception('Failed to update teacher profile: $e');
    }
  }

  // Listen to auth state changes
  static Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  // Reset password
  static Future<void> resetPassword(String email) async {
    try {
      await _client.auth.resetPasswordForEmail(email);
    } catch (e) {
      throw Exception('Failed to reset password: $e');
    }
  }

  // Verify if current user is a teacher
  static Future<bool> isCurrentUserTeacher() async {
    try {
      final user = currentUser;
      if (user == null) return false;

      final teacherProfile = await getTeacherProfile(user.id);
      return teacherProfile != null;
    } catch (e) {
      return false;
    }
  }

  // Get current teacher's subjects
  static Future<List<Map<String, dynamic>>> getCurrentTeacherSubjects() async {
    try {
      final user = currentUser;
      if (user == null) throw Exception('User not authenticated');

      final teacherProfile = await getTeacherProfile(user.id);
      if (teacherProfile == null) throw Exception('Teacher profile not found');

      return await _client
          .from('teacher_dashboard_view')
          .select('*')
          .eq('teacher_id', teacherProfile['id']);
    } catch (e) {
      throw Exception('Failed to get current teacher subjects: $e');
    }
  }
}

