import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as supabase;
import 'screens/login_screen.dart';
import 'screens/teacher_dashboard_screen.dart';
import 'cubits/theme_cubit.dart';
import 'cubits/auth_cubit.dart';
import 'cubits/attendance_cubit.dart';
import 'config/service_locator.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await supabase.Supabase.initialize(
    url: 'https://mhupkohpydhxiwrfwsnx.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1odXBrb2hweWRoeGl3cmZ3c254Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ5NTA4NDYsImV4cCI6MjA3MDUyNjg0Nn0.Eh2Lj_BNAxpmWh7dNjRODx4Bxq1I9DKEsgdUgoCO4i8',
  );
  
  await setupDependencies();
  runApp(

    DevicePreview(
      enabled: true,
      builder: (context) => const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => ThemeCubit()),
        BlocProvider(create: (_) => AuthCubit()),
        BlocProvider(create: (_) => serviceLocator<AttendanceCubit>()),
      ],
      child: BlocBuilder<ThemeCubit, ThemeState>(
        builder: (context, themeState) {
          final themeCubit = context.read<ThemeCubit>();
          return MaterialApp(
            useInheritedMediaQuery: true,
            builder: DevicePreview.appBuilder,
            locale: DevicePreview.locale(context),
            title: 'Teacher Attendance App',
            theme: themeCubit.lightTheme,
            darkTheme: themeCubit.darkTheme,
            themeMode: themeState.themeMode,
            home: const AuthWrapper(),
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, state) {
        if (state is AuthLoading || state is AuthInitial) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (state is AuthAuthenticated) {
          return const TeacherDashboardScreen();
        } else {
          return const LoginScreen();
        }
      },
    );
  }
}