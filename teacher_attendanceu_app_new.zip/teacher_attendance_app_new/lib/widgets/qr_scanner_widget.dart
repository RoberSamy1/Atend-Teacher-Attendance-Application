import 'package:flutter/material.dart';
import 'package:qr_code_scanner_plus/qr_code_scanner_plus.dart';
import '../controllers/qr_scanner_controller.dart';

class QRScannerWidget extends StatefulWidget {
  final Function(String studentId) onStudentIdScanned;
  final Function(String error)? onError;
  final QRScannerController controller;

  const QRScannerWidget({
    super.key,
    required this.onStudentIdScanned,
    required this.controller,
    this.onError,
  });

  @override
  State<QRScannerWidget> createState() => _QRScannerWidgetState();
}

class _QRScannerWidgetState extends State<QRScannerWidget> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  bool hasPermission = false;
  bool isScanning = true;
  QRViewController? _qrController;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }

  Future<void> _checkPermissions() async {
    final granted = await widget.controller.checkCameraPermission();
    if (!granted) {
      final requested = await widget.controller.requestCameraPermission();
      setState(() {
        hasPermission = requested;
      });
    } else {
      setState(() {
        hasPermission = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!hasPermission) {
      return _buildPermissionDeniedWidget();
    }

    return Column(
      children: [
        Expanded(
          child: QRView(
            key: qrKey,
            onQRViewCreated: _onQRViewCreated,
            overlay: QrScannerOverlayShape(
              borderColor: const Color(0xFF3B82F6),
              borderRadius: 10,
              borderLength: 30,
              borderWidth: 10,
              cutOutSize: 250,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildControlButton(
                icon: widget.controller.isFlashOn ? Icons.flash_off : Icons.flash_on,
                label: 'Flash',
                onPressed: _toggleFlash,
              ),
              _buildControlButton(
                icon: Icons.refresh,
                label: 'Reset',
                onPressed: _resetScanner,
              ),
              _buildControlButton(
                icon: Icons.flip_camera_ios,
                label: 'Flip',
                onPressed: _flipCamera,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPermissionDeniedWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.no_photography,
            size: 64,
            color: Colors.grey,
          ),
          const SizedBox(height: 16),
          const Text(
            'Camera permission is required',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              await widget.controller.requestCameraPermission();
              setState(() {});
            },
            child: const Text('Grant Permission'),
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF3B82F6),
            borderRadius: BorderRadius.circular(8),
          ),
          child: IconButton(
            onPressed: onPressed,
            icon: Icon(icon, color: Colors.white),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Color(0xFF6B7280),
          ),
        ),
      ],
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    _qrController = controller;
    controller.scannedDataStream.listen((scanData) {
      if (isScanning && scanData.code != null) {
        _handleScannedData(scanData.code!);
      }
    });
  }

  void _handleScannedData(String qrData) {
    setState(() {
      isScanning = false;
    });

    final validationResult = widget.controller.validateQRData(qrData);

    if (validationResult.isValid && validationResult.studentId != null) {
      widget.onStudentIdScanned(validationResult.studentId!);
    } else {
      final error = validationResult.error ?? 'Invalid QR code format';
      if (widget.onError != null) {
        widget.onError!(error);
      }

      // Reset scanner after a delay
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          _resetScanner();
        }
      });
    }
  }

  void _toggleFlash() async {
    if (_qrController != null) {
      await _qrController!.toggleFlash();
      setState(() {
        widget.controller.toggleFlash();
      });
    }
  }

  void _resetScanner() {
    setState(() {
      isScanning = true;
    });
  }

  void _flipCamera() async {
    if (_qrController != null) {
      await _qrController!.flipCamera();
    }
  }


}
