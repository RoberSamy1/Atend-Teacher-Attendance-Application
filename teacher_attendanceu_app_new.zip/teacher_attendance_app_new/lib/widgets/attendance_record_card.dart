import 'package:flutter/material.dart';
import '../models/attendance_record.dart';
import 'package:intl/intl.dart';

class AttendanceRecordCard extends StatelessWidget {
  final AttendanceRecord record;

  const AttendanceRecordCard({
    super.key,
    required this.record,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8.0),
      child: ListTile(
        leading: Icon(
          record.status == 'present' ? Icons.check_circle : Icons.cancel,
          color: record.status == 'present' ? Colors.green : Colors.red,
        ),
        title: Text(
          record.subjectName ?? 'Unknown Subject',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Date: ${DateFormat('MMM dd, yyyy').format(record.attendanceDate)}',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            if (record.location != null)
              Text(
                'Location: ${record.location}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
          ],
        ),
        trailing: Text(
          record.status.toUpperCase(),
          style: TextStyle(
            color: record.status == 'present' ? Colors.green : Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
