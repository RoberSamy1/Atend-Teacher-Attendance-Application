import '../models/attendance_record.dart';
import '../models/student.dart';
import '../cubits/attendance_cubit.dart';
import '../utils/qr_validator.dart';

class AttendanceController {
  final AttendanceCubit _attendanceCubit;

  AttendanceController(this._attendanceCubit);

  Future<void> loadInitialData() async {
    await _attendanceCubit.loadAttendanceData();
  }

  Future<void> markStudentAttendance({
    required String studentId,
    required String subjectId,
    required bool isPresent,
    String? notes,
  }) async {
    if (studentId.isEmpty || subjectId.isEmpty) {
      throw Exception('Student and subject must be selected');
    }

    await _attendanceCubit.markAttendance(
      studentId: studentId,
      subjectId: subjectId,
      isPresent: isPresent,
      notes: notes,
    );
  }

  Future<void> processQRScan(String qrData) async {
    if (qrData.isEmpty) {
      throw Exception('Invalid QR code data');
    }

    // Validate QR code format
    final validationResult = QRValidator.validateQRData(qrData);
    if (!validationResult.isValid) {
      throw Exception(validationResult.error ?? 'Invalid QR code format');
    }

    await _attendanceCubit.scanQRCode(validationResult.studentId!);
  }

  Future<void> exportAttendanceData({
    required DateTime startDate,
    required DateTime endDate,
    String? subjectId,
  }) async {
    if (startDate.isAfter(endDate)) {
      throw Exception('Start date cannot be after end date');
    }

    final daysDifference = endDate.difference(startDate).inDays;
    if (daysDifference > 365) {
      throw Exception('Date range cannot exceed 365 days');
    }

    await _attendanceCubit.exportAttendance(
      startDate: startDate,
      endDate: endDate,
      subjectId: subjectId,
    );
  }

  Future<void> getFilteredAttendanceHistory({
    DateTime? startDate,
    DateTime? endDate,
    String? subjectId,
  }) async {
    if (startDate != null && endDate != null && startDate.isAfter(endDate)) {
      throw Exception('Start date cannot be after end date');
    }

    await _attendanceCubit.getAttendanceHistory(
      startDate: startDate,
      endDate: endDate,
      subjectId: subjectId,
    );
  }

  List<Student> searchStudents(List<Student> students, String query) {
    if (query.isEmpty) return students;

    return students.where((student) {
      return student.name.toLowerCase().contains(query.toLowerCase()) ||
             student.studentId.toLowerCase().contains(query.toLowerCase()) ||
             (student.email?.toLowerCase() ?? '').contains(query.toLowerCase());
    }).toList();
  }

  List<AttendanceRecord> getStudentAttendanceRecords(
    List<AttendanceRecord> records,
    String studentId,
  ) {
    return records.where((record) => record.studentId == studentId).toList();
  }

  double calculateAttendancePercentage(
    List<AttendanceRecord> records,
    String studentId,
  ) {
    final studentRecords = getStudentAttendanceRecords(records, studentId);
    if (studentRecords.isEmpty) return 0.0;

    final presentCount = studentRecords.where((record) => record.status == 'present').length;
    return (presentCount / studentRecords.length) * 100;
  }

  Map<String, int> getAttendanceStats(List<AttendanceRecord> records) {
    final totalRecords = records.length;
    final presentCount = records.where((record) => record.status == 'present').length;
    final absentCount = totalRecords - presentCount;

    return {
      'total': totalRecords,
      'present': presentCount,
      'absent': absentCount,
    };
  }

  void clearError() {
    _attendanceCubit.clearError();
  }

  bool isValidDateRange(DateTime? startDate, DateTime? endDate) {
    if (startDate == null || endDate == null) return true;
    return !startDate.isAfter(endDate);
  }

  String formatAttendancePercentage(double percentage) {
    return '${percentage.toStringAsFixed(1)}%';
  }
}

