import 'package:flutter/material.dart';
import '../cubits/theme_cubit.dart';

class ThemeController {
  final ThemeCubit _themeCubit;

  ThemeController(this._themeCubit);

  void toggleTheme() {
    _themeCubit.toggleTheme();
  }

  bool get isDarkMode {
    return _themeCubit.state.themeMode == ThemeMode.dark;
  }

  ThemeMode get currentThemeMode {
    return _themeCubit.state.themeMode;
  }

  ThemeData get lightTheme {
    return _themeCubit.lightTheme;
  }

  ThemeData get darkTheme {
    return _themeCubit.darkTheme;
  }

  String get themeDisplayName {
    return isDarkMode ? 'Dark Mode' : 'Light Mode';
  }

  IconData get themeIcon {
    return isDarkMode ? Icons.light_mode : Icons.dark_mode;
  }

  String get toggleThemeText {
    return isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode';
  }
}

