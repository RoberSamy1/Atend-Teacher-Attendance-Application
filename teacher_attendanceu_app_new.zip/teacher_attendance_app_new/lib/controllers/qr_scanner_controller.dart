import 'package:qr_code_scanner_plus/qr_code_scanner_plus.dart';
import '../utils/permissions_helper.dart';
import '../utils/qr_validator.dart';
import 'package:logger/logger.dart';

class QRScannerController {
  final PermissionsHelper _permissionsHelper;
  final Logger _logger;
  QRViewController? _qrViewController;
  bool _isScanning = true;
  bool _isFlashOn = false;

  QRScannerController(this._permissionsHelper) : _logger = Logger();

  bool get isScanning => _isScanning;
  bool get isFlashOn => _isFlashOn;
  QRViewController? get qrViewController => _qrViewController;

  void setQRViewController(QRViewController controller) {
    _qrViewController = controller;
  }

  Future<bool> checkCameraPermission() async {
    try {
      return await _permissionsHelper.isCameraPermissionGranted();
    } catch (e) {
      _logger.e('Failed to check camera permission', error: e);
      return false;
    }
  }

  Future<bool> requestCameraPermission() async {
    try {
      return await _permissionsHelper.requestCameraPermission();
    } catch (e) {
      _logger.e('Failed to request camera permission', error: e);
      return false;
    }
  }

  Future<void> openAppSettings() async {
    try {
      await _permissionsHelper.openSettings();
    } catch (e) {
      _logger.e('Failed to open app settings', error: e);
    }
  }

  Future<void> toggleFlash() async {
    try {
      if (_qrViewController != null) {
        await _qrViewController!.toggleFlash();
        _isFlashOn = !_isFlashOn;
      }
    } catch (e) {
      _logger.e('Failed to toggle flash', error: e);
    }
  }

  Future<void> flipCamera() async {
    try {
      if (_qrViewController != null) {
        await _qrViewController!.flipCamera();
      }
    } catch (e) {
      _logger.e('Failed to flip camera', error: e);
    }
  }

  void resetScanning() {
    _isScanning = true;
  }

  void pauseScanning() {
    _isScanning = false;
  }

  QRValidationResult validateQRData(String qrData) {
    try {
      return QRValidator.validateQRData(qrData);
    } catch (e) {
      _logger.e('Failed to validate QR data', error: e);
      return QRValidationResult(
        isValid: false,
        error: 'Failed to validate QR code',
      );
    }
  }

  void dispose() {
    _qrViewController?.dispose();
    _qrViewController = null;
  }
}
