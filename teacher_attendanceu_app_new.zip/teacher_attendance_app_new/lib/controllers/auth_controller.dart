import '../services/auth_service.dart';
import '../cubits/auth_cubit.dart';

class AuthController {
  final AuthCubit _authCubit;

  AuthController(this._authCubit);

  Future<void> handleSignIn(String email, String password) async {
    if (email.isEmpty || password.isEmpty) {
      throw Exception('Email and password are required');
    }

    if (!_isValidEmail(email)) {
      throw Exception('Please enter a valid email address');
    }

    await _authCubit.signIn(email, password);
  }

  Future<void> handleSignUp(String email, String password, String fullName) async {
    if (email.isEmpty || password.isEmpty || fullName.isEmpty) {
      throw Exception('All fields are required');
    }

    if (!_isValidEmail(email)) {
      throw Exception('Please enter a valid email address');
    }

    if (password.length < 6) {
      throw Exception('Password must be at least 6 characters long');
    }

    await _authCubit.signUp(email, password, fullName);
  }

  Future<void> handleSignOut() async {
    await _authCubit.signOut();
  }

  bool _isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  void clearError() {
    _authCubit.clearError();
  }

  bool get isAuthenticated {
    return AuthService.currentUser != null;
  }

  String? get currentUserEmail {
    return AuthService.currentUser?.email;
  }

  String? get currentUserId {
    return AuthService.currentUser?.id;
  }
}

