import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/attendance_record.dart';
import '../models/student.dart';
import '../services/supabase_service.dart';

import './interfaces/attendance_repository_interface.dart';

class SupabaseAttendanceRepository implements IAttendanceRepository {
  static const String _attendanceTable = 'attendance_records';
  static const String _studentsTable = 'students';
  static const String _teachersTable = 'teachers';
  
  final SupabaseClient _client;
  
  SupabaseAttendanceRepository(this._client);

  @override
  Future<AttendanceRecord> recordAttendance(
    String studentId, {
    String? studentName,
    String? location,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final teacherId = await _getTeacherId(user.id);
      final subjectInfo = await _getCurrentSubjectInfo(user.id);
      final student = await _findOrCreateStudent(studentId, studentName);
      
      await _validateAttendanceNotRecorded(studentId, subjectInfo['subject_id']);

      final attendanceData = _createAttendanceData(
        student: student,
        teacherId: teacherId,
        subjectId: subjectInfo['subject_id'],
        classId: subjectInfo['class_id'],
        location: location,
      );

      final response = await SupabaseService.insert(
        table: _attendanceTable,
        data: attendanceData,
      );

      return AttendanceRecord.fromJson({
        ...response,
        'student_name': student.name,
        'student_id_text': student.studentId,
      });
    } catch (e) {
      throw Exception('Failed to record attendance: ${e.toString().replaceAll('Exception: ', '')}');
    }
  }

  @override
  Future<List<AttendanceRecord>> getAttendanceRecords({
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final teacherId = await _getTeacherId(user.id);
      final records = await _fetchAttendanceRecords(teacherId, limit);
      
      return _filterAndMapAttendanceRecords(records, startDate, endDate);
    } catch (e) {
      throw Exception('Failed to get attendance records: $e');
    }
  }

  @override
  Future<List<AttendanceRecord>> getStudentAttendanceRecords(
    String studentId, {
    int? limit,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      final records = await _fetchStudentAttendanceRecords(studentId, limit);
      return _filterAndMapAttendanceRecords(records, startDate, endDate);
    } catch (e) {
      throw Exception('Failed to get student attendance records: $e');
    }
  }

  @override
  Future<Map<String, int>> getAttendanceStats() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final teacherId = await _getTeacherId(user.id);
      final response = await _client
          .from(_attendanceTable)
          .select('status')
          .eq('teacher_id', teacherId);

      return _calculateAttendanceStats(response);
    } catch (e) {
      throw Exception('Failed to get attendance statistics: $e');
    }
  }

  @override
  Future<int> getTodayAttendanceCount() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final teacherId = await _getTeacherId(user.id);
      final today = DateTime.now().toIso8601String().split('T')[0];

      final response = await _client
          .from(_attendanceTable)
          .select('id')
          .eq('teacher_id', teacherId)
          .eq('attendance_date', today);

      return response.length;
    } catch (e) {
      throw Exception('Failed to get today\'s attendance count: $e');
    }
  }

  @override
  Future<int> getUniqueStudentsCount() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final teacherId = await _getTeacherId(user.id);
      final response = await _client
          .from(_attendanceTable)
          .select('student_id')
          .eq('teacher_id', teacherId);

      return _countUniqueStudents(response);
    } catch (e) {
      throw Exception('Failed to get unique students count: $e');
    }
  }

  // Private helper methods
  Future<String> _getTeacherId(String userId) async {
    final teacherResponse = await _client
        .from(_teachersTable)
        .select('id')
        .eq('auth_user_id', userId)
        .single();
    return teacherResponse['id'];
  }

  Future<Map<String, dynamic>> _getCurrentSubjectInfo(String userId) async {
    final response = await _client
        .from('teacher_dashboard_view')
        .select('subject_id, class_id, subject_name')
        .eq('auth_user_id', userId)
        .limit(1)
        .single();
    return response;
  }

  Future<Student> _findOrCreateStudent(String studentId, String? studentName) async {
    try {
      return await _findStudentByStudentId(studentId);
    } catch (e) {
      if (studentName?.isNotEmpty ?? false) {
        return await _createStudent(studentId, studentName!);
      }
      throw Exception('Student not found and no name provided to create new record');
    }
  }

  Future<Student> _findStudentByStudentId(String studentId) async {
    final response = await _client
        .from(_studentsTable)
        .select('*')
        .eq('student_id', studentId)
        .single();
    return Student.fromJson(response);
  }

  Future<Student> _createStudent(String studentId, String name) async {
    final studentData = {
      'student_id': studentId,
      'name': name,
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    };

    final response = await SupabaseService.insert(
      table: _studentsTable,
      data: studentData,
    );

    return Student.fromJson(response);
  }

  Future<void> _validateAttendanceNotRecorded(String studentId, String subjectId) async {
    final today = DateTime.now().toIso8601String().split('T')[0];
    final existingAttendance = await _client
        .from(_attendanceTable)
        .select('id')
        .eq('student_id', studentId)
        .eq('subject_id', subjectId)
        .eq('attendance_date', today)
        .maybeSingle();

    if (existingAttendance != null) {
      throw Exception('Attendance already recorded for this student today in this subject');
    }
  }

  Map<String, dynamic> _createAttendanceData({
    required Student student,
    required String teacherId,
    required String subjectId,
    String? classId,
    String? location,
  }) {
    final data = {
      'student_id': student.studentId,
      'student_name': student.name,
      'teacher_id': teacherId,
      'subject_id': subjectId,
      'status': 'present',
      'attendance_date': DateTime.now().toIso8601String().split('T')[0],
      'location': location ?? 'Campus',
      'created_at': DateTime.now().toIso8601String(),
    };

    if (classId != null && classId.trim().isNotEmpty && classId.toLowerCase() != 'null') {
      data['class_id'] = classId;
    }

    return data;
  }

  Future<List<Map<String, dynamic>>> _fetchAttendanceRecords(String teacherId, int? limit) async {
    var query = _client
        .from(_attendanceTable)
        .select('''
          *,
          students(student_id, name),
          subjects(subject_name)
        ''')
        .eq('teacher_id', teacherId)
        .order('created_at', ascending: false);

    if (limit != null) {
      query = query.limit(limit);
    }

    return await query;
  }

  Future<List<Map<String, dynamic>>> _fetchStudentAttendanceRecords(String studentId, int? limit) async {
    var query = _client
        .from(_attendanceTable)
        .select('''
          *,
          students!inner(student_id, name),
          subjects!inner(subject_name)
        ''')
        .eq('student_id', studentId)
        .order('created_at', ascending: false);

    if (limit != null) {
      query = query.limit(limit);
    }

    return await query;
  }

  List<AttendanceRecord> _filterAndMapAttendanceRecords(
    List<Map<String, dynamic>> records,
    DateTime? startDate,
    DateTime? endDate,
  ) {
    var filteredRecords = records;

    if (startDate != null || endDate != null) {
      filteredRecords = records.where((record) {
        final attendanceDate = DateTime.tryParse(record['attendance_date']);
        if (attendanceDate == null) return false;

        bool matchesStart = startDate == null ||
            attendanceDate.isAfter(startDate.subtract(const Duration(days: 1)));
        bool matchesEnd = endDate == null ||
            attendanceDate.isBefore(endDate.add(const Duration(days: 1)));

        return matchesStart && matchesEnd;
      }).toList();
    }

    return filteredRecords.map<AttendanceRecord>((json) {
      return AttendanceRecord.fromJson({
        ...json,
        'student_name': json['students']?['name'] ?? '',
        'student_id_text': json['students']?['student_id'] ?? '',
        'subject_name': json['subjects']?['subject_name'] ?? '',
      });
    }).toList();
  }

  Map<String, int> _calculateAttendanceStats(List<Map<String, dynamic>> records) {
    final stats = <String, int>{
      'total': records.length,
      'present': 0,
      'absent': 0,
      'late': 0,
    };

    for (final record in records) {
      final status = record['status'] as String? ?? 'present';
      stats[status] = (stats[status] ?? 0) + 1;
    }

    return stats;
  }

  int _countUniqueStudents(List<Map<String, dynamic>> records) {
    final uniqueStudentIds = <String>{};
    for (final record in records) {
      uniqueStudentIds.add(record['student_id'] as String);
    }
    return uniqueStudentIds.length;
  }
}
