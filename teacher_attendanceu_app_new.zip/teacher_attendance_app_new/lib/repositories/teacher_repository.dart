import 'package:supabase_flutter/supabase_flutter.dart';

abstract class ITeacherRepository {
  Future<Map<String, dynamic>?> getCurrentTeacherInfo();
  Future<String> getTeacherId(String userId);
  Future<List<Map<String, dynamic>>> getTeacherSubjects(String teacherId);
}

class SupabaseTeacherRepository implements ITeacherRepository {
  static const String _teachersTable = 'teachers';
  
  final SupabaseClient _client;
  
  SupabaseTeacherRepository(this._client);

  @override
  Future<Map<String, dynamic>?> getCurrentTeacherInfo() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) return null;

      final response = await _client
          .from('teacher_dashboard_view')
          .select('*')
          .eq('auth_user_id', user.id)
          .limit(1)
          .maybeSingle();

      return response;
    } catch (e) {
      print('Error getting teacher info: $e');
      return null;
    }
  }

  @override
  Future<String> getTeacherId(String userId) async {
    final response = await _client
        .from(_teachersTable)
        .select('id')
        .eq('auth_user_id', userId)
        .single();
    return response['id'];
  }

  @override
  Future<List<Map<String, dynamic>>> getTeacherSubjects(String teacherId) async {
    final response = await _client
        .from('teacher_subject_assignments')
        .select('subject_id, class_id')
        .eq('teacher_id', teacherId)
        .eq('status', 'active');
    return response;
  }
}
