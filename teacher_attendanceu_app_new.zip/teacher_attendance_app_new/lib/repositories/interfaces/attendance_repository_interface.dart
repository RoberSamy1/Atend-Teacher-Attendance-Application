import '../../models/attendance_record.dart';

abstract class IAttendanceRepository {
  Future<AttendanceRecord> recordAttendance(String studentId, {String? studentName, String? location});
  Future<List<AttendanceRecord>> getAttendanceRecords({int? limit, DateTime? startDate, DateTime? endDate});
  Future<List<AttendanceRecord>> getStudentAttendanceRecords(String studentId, {int? limit, DateTime? startDate, DateTime? endDate});
  Future<Map<String, int>> getAttendanceStats();
  Future<int> getTodayAttendanceCount();
  Future<int> getUniqueStudentsCount();
}
