import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/student.dart';

abstract class IStudentRepository {
  Future<List<Student>> getAllStudents();
  Future<List<Student>> searchStudents(String query);
  Future<Student> addOrUpdateStudent(Student student);
}

class SupabaseStudentRepository implements IStudentRepository {
  static const String _studentsTable = 'students';
  static const String _teachersTable = 'teachers';
  
  final SupabaseClient _client;
  
  SupabaseStudentRepository(this._client);

  @override
  Future<List<Student>> getAllStudents() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      try {
        final response = await _client.from(_studentsTable).select('''
          *,
          classes!inner(
            id,
            name,
            teacher_id,
            teachers!inner(auth_user_id)
          )
        ''').eq('classes.teachers.auth_user_id', user.id).order('name');

        return _mapStudentsResponse(response);
      } catch (e) {
        // Fallback: get all students if the above fails
        final response = await _client.from(_studentsTable).select('''
          *,
          classes (
            id,
            name
          )
        ''').order('name');

        return _mapStudentsResponse(response);
      }
    } catch (e) {
      throw Exception('Failed to get students: $e');
    }
  }

  @override
  Future<List<Student>> searchStudents(String query) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final teacherId = await _getTeacherId(user.id);
      final classIds = await _getTeacherClassIds(teacherId);

      if (classIds.isEmpty) {
        return [];
      }

      final response = await _client
          .from('students')
          .select('''
            *,
            classes!inner (
              id,
              name
            )
          ''')
          .filter('class_id', 'in', '(${classIds.join(',')})')
          .or('student_id.ilike.%${query}%,name.ilike.%${query}%')
          .order('name');

      return _mapStudentsResponse(response);
    } catch (e) {
      throw Exception('Failed to search students: $e');
    }
  }

  @override
  Future<Student> addOrUpdateStudent(Student student) async {
    try {
      _validateStudentData(student);

      try {
        final existingStudent = await _findStudentByStudentId(student.studentId);
        return await _updateStudent(existingStudent.id, student);
      } catch (e) {
        return await _createStudent(student);
      }
    } catch (e) {
      throw Exception('Failed to add or update student: $e');
    }
  }

  // Private helper methods
  Future<String> _getTeacherId(String userId) async {
    final response = await _client
        .from(_teachersTable)
        .select('id')
        .eq('auth_user_id', userId)
        .single();
    return response['id'];
  }

  Future<List<String>> _getTeacherClassIds(String teacherId) async {
    final response = await _client
        .from('teacher_subject_assignments')
        .select('class_id')
        .eq('teacher_id', teacherId)
        .eq('status', 'active');

    return response
        .map((s) => s['class_id']?.toString())
        .where((id) => id != null && id.isNotEmpty && id.toLowerCase() != 'null')
        .cast<String>()
        .toList();
  }

  List<Student> _mapStudentsResponse(List<Map<String, dynamic>> response) {
    return response.map((json) => Student.fromJson({
          ...json,
          'class_name': json['classes']?['name'],
          'class_id': json['classes']?['id'],
        })).toList();
  }

  void _validateStudentData(Student student) {
    if (student.studentId.isEmpty) {
      throw Exception('Student ID cannot be empty');
    }
    if (student.name.isEmpty) {
      throw Exception('Student name cannot be empty');
    }
  }

  Future<Student> _findStudentByStudentId(String studentId) async {
    final response = await _client
        .from(_studentsTable)
        .select('*')
        .eq('student_id', studentId)
        .single();
    return Student.fromJson(response);
  }

  Future<Student> _updateStudent(String id, Student student) async {
    final updatedData = {
      'name': student.name,
      'email': student.email,
      'phone': student.phone,
      'department': student.department,
      'year': student.year,
      'updated_at': DateTime.now().toIso8601String(),
    };

    if (student.classId != null && student.classId!.trim().isNotEmpty) {
      updatedData['class_id'] = student.classId!.trim();
    }

    final response = await _client
        .from(_studentsTable)
        .update(updatedData)
        .eq('id', id)
        .single();

    return Student.fromJson(response);
  }

  Future<Student> _createStudent(Student student) async {
    final studentData = {
      'student_id': student.studentId,
      'name': student.name,
      'email': student.email,
      'phone': student.phone,
      'department': student.department,
      'year': student.year,
      'class_id': student.classId,
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    };

    final response = await _client
        .from(_studentsTable)
        .insert(studentData)
        .single();

    return Student.fromJson(response);
  }
}
