class AttendanceRecord {
  final String id;
  final String studentId;
  final String? studentName;
  final DateTime timestamp;
  final String? location;
  final String status;
  final String? subjectName;
  final DateTime attendanceDate;

  AttendanceRecord({
    required this.id,
    required this.studentId,
    this.studentName,
    required this.timestamp,
    this.location,
    this.status = 'present',
    this.subjectName,
    DateTime? attendanceDate,
  }) : this.attendanceDate = attendanceDate ?? timestamp;

  factory AttendanceRecord.fromJson(Map<String, dynamic> json) {
    return AttendanceRecord(
      id: json['id'] as String,
      studentId: json['student_id'] as String,
      studentName: json['student_name'] as String?,
      timestamp: DateTime.parse(json['created_at'] as String),
      location: json['location'] as String?,
      status: json['status'] as String? ?? 'present',
      subjectName: json['subject_name'] as String?,
      attendanceDate: DateTime.parse(json['attendance_date'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'student_id': studentId,
      'student_name': studentName,
      'timestamp': timestamp.toIso8601String(),
      'location': location,
      'status': status,
      'subject_name': subjectName,
      'attendance_date': attendanceDate.toIso8601String(),
    };
  }

  Map<String, dynamic> toInsertJson() {
    return {
      'student_id': studentId,
      'student_name': studentName,
      'timestamp': timestamp.toIso8601String(),
      'location': location,
      'status': status,
      'attendance_date': attendanceDate.toIso8601String(),
    };
  }

  @override
  String toString() {
    return 'AttendanceRecord{id: $id, studentId: $studentId, studentName: $studentName, timestamp: $timestamp, location: $location, status: $status}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AttendanceRecord &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}

