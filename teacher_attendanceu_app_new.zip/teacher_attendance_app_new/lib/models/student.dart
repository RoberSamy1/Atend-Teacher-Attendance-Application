class Student {
  final String id;
  final String studentId;
  final String name;
  final String? email;
  final String? phone;
  final String? department;
  final String? year;
  final String? className;
  final String? classId;
  final DateTime createdAt;
  final DateTime updatedAt;

  Student({
    required this.id,
    required this.studentId,
    required this.name,
    this.email,
    this.phone,
    this.department,
    this.year,
    this.className,
    this.classId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id'] as String,
      studentId: json['student_id'] as String,
      name: json['name'] as String,
      email: json['email'] as String?,
      phone: json['phone'] as String?,
      department: json['department'] as String?,
      year: json['year'] as String?,
      className: json['class_name'] as String?,
      classId: json['class_id'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'student_id': studentId,
      'name': name,
      'email': email,
      'phone': phone,
      'department': department,
      'year': year,
      'class_name': className,
      'class_id': classId,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  Map<String, dynamic> toInsertJson() {
    return {
      'student_id': studentId,
      'name': name,
      'email': email,
      'phone': phone,
      'department': department,
      'year': year,
      'class_name': className,
      'class_id': classId,
    };
  }

  Student copyWith({
    String? id,
    String? studentId,
    String? name,
    String? email,
    String? phone,
    String? department,
    String? year,
    String? className,
    String? classId,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Student(
      id: id ?? this.id,
      studentId: studentId ?? this.studentId,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      department: department ?? this.department,
      year: year ?? this.year,
      className: className ?? this.className,
      classId: classId ?? this.classId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'Student{id: $id, studentId: $studentId, name: $name, email: $email, phone: $phone, department: $department, year: $year, className: $className, classId: $classId}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Student &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}

