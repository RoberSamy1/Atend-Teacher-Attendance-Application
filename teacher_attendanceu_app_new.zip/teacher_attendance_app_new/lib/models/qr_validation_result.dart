class QRValidationResult {
  final bool isValid;
  final String? studentId;
  final String? error;

  const QRValidationResult({
    required this.isValid,
    this.studentId,
    this.error,
  });
}
