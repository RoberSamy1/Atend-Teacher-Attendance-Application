class Subject {
  final String id;
  final String subjectCode;
  final String subjectName;
  final String? department;
  final DateTime createdAt;
  final DateTime updatedAt;

  Subject({
    required this.id,
    required this.subjectCode,
    required this.subjectName,
    this.department,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Subject.fromJson(Map<String, dynamic> json) {
    return Subject(
      id: json['id'] as String,
      subjectCode: json['subject_code'] as String,
      subjectName: json['subject_name'] as String,
      department: json['department'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'subject_code': subjectCode,
      'subject_name': subjectName,
      'department': department,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  Map<String, dynamic> toInsertJson() {
    return {
      'subject_code': subjectCode,
      'subject_name': subjectName,
      'department': department,
    };
  }

  Subject copyWith({
    String? id,
    String? subjectCode,
    String? subjectName,
    String? department,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Subject(
      id: id ?? this.id,
      subjectCode: subjectCode ?? this.subjectCode,
      subjectName: subjectName ?? this.subjectName,
      department: department ?? this.department,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'Subject{id: $id, subjectCode: $subjectCode, subjectName: $subjectName, department: $department}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Subject &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}

