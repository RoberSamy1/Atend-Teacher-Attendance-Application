class Lecture {
  final String id;  // UUID as string
  final String name;
  final String subjectId;  // UUID as string
  final String teacherId;
  final DateTime date;
  final DateTime createdAt;

  Lecture({
    required this.id,
    required this.name,
    required this.subjectId,
    required this.teacherId,
    required this.date,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'subject_id': subjectId,
      'teacher_id': teacherId,
      'date': date.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Lecture.fromMap(Map<String, dynamic> map) {
    return Lecture(
      id: map['id'],
      name: map['name'],
      subjectId: map['subject_id'],
      teacherId: map['teacher_id'],
      date: DateTime.parse(map['date']),
      createdAt: DateTime.parse(map['created_at']),
    );
  }
}
