# Teacher Attendance Management System

A Flutter application for teachers to manage student attendance with Supabase backend integration.

## Features

- **Teacher Authentication**: Secure login/signup system for teachers
- **Subject Management**: Teachers can view their assigned subjects and classes
- **Attendance Tracking**: Mark students as present or absent
- **Data Export**: Export attendance data and summaries to Excel files
- **Real-time Updates**: Live attendance records with instant feedback
- **Responsive Design**: Works on both mobile and desktop platforms

## Prerequisites

- Flutter SDK (3.0.0 or higher)
- Dart SDK
- Android Studio / VS Code
- Supabase account

## Setup Instructions

### 1. Database Setup

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Run the SQL scripts in the following order:
   - First, run the content from `pasted_content.txt` (initial database schema)
   - Then, run `database_update.sql` (authentication updates)

### 2. Flutter App Setup

1. Clone or extract the project files
2. Navigate to the project directory:
   ```bash
   cd attehhhhhhhn
   ```

3. Install dependencies:
   ```bash
   flutter pub get
   ```

4. Update Supabase configuration in `lib/main.dart`:
   ```dart
   await Supabase.initialize(
     url: 'YOUR_SUPABASE_URL',
     anonKey: 'YOUR_SUPABASE_ANON_KEY',
   );
   ```

5. Run the application:
   ```bash
   flutter run
   ```

## Usage

### For Teachers

1. **Sign Up**: Create a new teacher account with your details
2. **Login**: Sign in with your email and password
3. **View Subjects**: See all subjects and classes assigned to you
4. **Mark Attendance**: 
   - Select a subject/class
   - Enter student ID
   - Mark as Present or Absent
5. **Export Data**:
   - Click the download icon in the attendance screen
   - Choose between attendance records or summary export
   - Files are saved to your device's Downloads folder

### For Administrators

1. Use the Supabase dashboard to:
   - Add students to the `students` table
   - Create subjects in the `subjects` table
   - Assign teachers to subjects via `teacher_subjects` table
   - Create classes in the `classes` table

## Database Schema

### Main Tables

- **teachers**: Teacher profiles with authentication
- **students**: Student information
- **subjects**: Course/subject definitions
- **classes**: Class instances for subjects
- **teacher_subjects**: Many-to-many relationship between teachers and subjects
- **attendance_records**: Individual attendance entries

### Views

- **teacher_dashboard_view**: Shows teachers their assigned subjects and classes
- **student_attendance_summary**: Provides attendance statistics per student

## File Structure

```
lib/
├── main.dart                 # App entry point
├── services/
│   ├── auth_service.dart     # Authentication logic
│   ├── supabase_service.dart # Database operations
│   └── export_service.dart   # Excel export functionality
├── screens/
│   ├── login_screen.dart           # Teacher login
│   ├── signup_screen.dart          # Teacher registration
│   ├── teacher_dashboard_screen.dart # Main dashboard
│   └── teacher_attendance_screen.dart # Attendance marking
└── models/                   # Data models (if any)
```

## Security Features

- Row Level Security (RLS) policies ensure teachers can only access their own data
- Authentication required for all operations
- Secure password handling via Supabase Auth

## Export Features

The app supports exporting data in Excel format:

1. **Attendance Records**: Detailed list of all attendance entries
2. **Attendance Summary**: Statistical overview with attendance percentages

Files are automatically named with timestamps and saved to the Downloads folder.

## Troubleshooting

### Common Issues

1. **Build Errors**: Run `flutter clean` then `flutter pub get`
2. **Database Connection**: Verify Supabase URL and keys in `main.dart`
3. **Permission Issues**: Ensure storage permissions are granted for exports
4. **Authentication Problems**: Check RLS policies in Supabase dashboard

### Support

For technical support or questions about the application, please refer to:
- Flutter documentation: [flutter.dev](https://flutter.dev)
- Supabase documentation: [supabase.com/docs](https://supabase.com/docs)

## Version History

- **v1.0.0**: Initial release with core attendance management features
  - Teacher authentication
  - Subject/class management
  - Attendance tracking
  - Excel export functionality

---

## Getting Started: FlutLab - Flutter Online IDE

- How to use FlutLab? Please, view our https://flutlab.io/docs
- Join the discussion and conversation on https://flutlab.io/residents
