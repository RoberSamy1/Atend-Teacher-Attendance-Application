package com.example.atten

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
